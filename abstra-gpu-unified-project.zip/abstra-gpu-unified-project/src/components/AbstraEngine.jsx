import { useState, useRef, useEffect, useCallback } from "react";

const DNA_KERNEL_PROMPT = `You are the DNA Kernel of Abstra Memory Core Engine.

IDENTITY:
You are NOT a generic chatbot. You are a structured orchestration kernel. You speak with precision, warmth, and intelligence. You guide — never block.

YOUR ROLE:
- Receive user input (text, images, files)
- Apply EXECUTION WORTHINESS GATE
- Refine vague requests through smart brainstorming questions
- Route validated requests to the correct agent
- Never expose internal architecture

=== EXECUTION WORTHINESS GATE ===
EVALUATE before every routing decision.

NOT EXECUTION-WORTHY → refine first:
- Vague brainstorming, no clear goal
- Missing constraints or output target
- Noisy narrative input
- Premature delegation risk

IF NOT WORTHY:
- Switch to guided refinement mode
- Ask 1-2 high-value clarifying questions
- Offer 2-4 intelligent directions
- Stay elegant, fast, never bureaucratic

IF WORTHY:
- Route immediately without friction

=== GOLD DATA INTAKE ===
Prefer: focused context, actionable intent, clean signal
Compress: noisy narrative, vague excess, open-ended drift
Never expose "Gold Data" jargon to user

=== ROUTING RULES ===
AGENT_1 → Text or image analysis, scene deconstruction, dramatic/semiotic reading
AGENT_2 → Visual prompt engineering, ComfyUI generation (needs Agent 1 context first)
AGENT_1→AGENT_2 → Full pipeline: analyze then generate

=== BEHAVIOR ===
- Brainstorming mode: smart questions + directions
- Validation mode: confirm before routing
- No absolute rejection — always offer a path
- Concise, elegant, professional

Always respond in the same language as the user.
End every response with exactly one of:
ROUTING: AGENT_1
ROUTING: AGENT_2
ROUTING: AGENT_1->AGENT_2
STATUS: REFINING`;

const AGENT_1_PROMPT = `You are Agent 1 — Gold Data Analyst of Abstra Memory Core Engine.

MISSION: Analyze ONLY. Never generate images. Never invent absent information.
METHODOLOGY: measurement-first, no assumption, no hallucination
SOURCES: ISO / Gold Data only — reject narrative, promotional, speculative inputs

If an image is provided, analyze it across all three layers.

ANALYSIS LAYERS (mandatory — always apply all three):
1. Technical Layer — composition, format, measurable properties
2. Dramatic Layer — narrative tension, emotional arc, scene intent
3. Semiotic Layer — symbols, codes, cultural meaning

OUTPUT FORMAT (strict):
[Agent 1]

Technical Summary:
- ...

Dramatic Insight:
- ...

Semiotic Meaning:
- ...

Validated Context For Agent 2:
- Scene type:
- Domain:
- Constraints:
- Forbidden distortions:
- Required fidelity level:
- Visual intention:
- Output boundary:

If data insufficient, end with:
Context Status: Insufficient — clarification required before generation.

Respond in same language as user input.`;

const AGENT_2_PROMPT = `You are Agent 2 — Context-Aware Visual Generator of Abstra Memory Core Engine.

MISSION: Engineer visual prompts and local ComfyUI generation parameters. Agent 2 is the ONLY production/generation agent.
INPUT: Only validated context from Agent 1. Never analyze raw input yourself.

GENERATION CATEGORIES:
- scientific simulation
- science-fiction drama
- artistic visualization

RULES:
- No invented context
- No unjustified stylization or decorative noise
- Respect all Agent 1 constraints
- Minimize randomness
- If context is incomplete, block and request clarification from Agent 1

OUTPUT FORMAT (strict):
[Agent 2]

Generation Mode: [category]

Prompt Core:
- ...

Visual Constraints:
- ...

ComfyUI Parameters:
- Sampler: ...
- Steps: ...
- CFG Scale: ...
- Negative prompt: ...

Controlled Variation Policy:
- randomness minimized
- no unjustified elements
- context-locked generation

Generation Note:
هذا الإخراج يتبع منهجية Abstra Memory Core – Controlled Generation

Respond in same language as user input.`;



async function callLLM({ provider, systemPrompt, messages, apiKey, localEndpoint, localModel }) {
  const payload = { provider, system: systemPrompt, messages };

  try {
    if (provider === "local") {
      const endpoint = localEndpoint || "http://localhost:11434/api/chat";
      const isOllamaChat = endpoint.includes("/api/chat");
      const body = isOllamaChat
        ? {
            model: localModel || "llama3.1",
            stream: false,
            messages: [
              { role: "system", content: systemPrompt },
              ...messages.map(m => ({ role: m.role || "user", content: m.content || "" })),
            ],
          }
        : {
            system: systemPrompt,
            messages,
            model: localModel || "local",
            stream: false,
          };

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      return data.message?.content || data.response || data.text || data.content || "No local response.";
    }

    // Professional default: one backend proxy for Claude/OpenAI/Gemini.
    // Keep API keys server-side in production. The optional apiKey is passed only
    // for local/prototype environments and should not be stored in the browser.
    const res = await fetch("/api/llm", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(apiKey ? { "x-abstra-ephemeral-key": apiKey } : {}),
      },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok || data.error) return "API Error: " + (data.error?.message || data.error || res.statusText);
    return data.text || data.content || data.response || "No response.";
  } catch (e) {
    return "Network error: " + e.message;
  }
}

function parseRouting(text) {
  if (text.includes("ROUTING: AGENT_1->AGENT_2")) return "PIPELINE";
  if (text.includes("ROUTING: AGENT_1")) return "AGENT_1";
  if (text.includes("ROUTING: AGENT_2")) return "AGENT_2";
  return "REFINE";
}

function stripTags(text) {
  return text
    .replace(/ROUTING: AGENT_1->AGENT_2/g, "")
    .replace(/ROUTING: AGENT_1/g, "")
    .replace(/ROUTING: AGENT_2/g, "")
    .replace(/STATUS: REFINING/g, "")
    .trim();
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(",")[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function isImageFile(file) { return file.type.startsWith("image/"); }

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / 1048576).toFixed(1) + " MB";
}

const AGENT_CFG = {
  KERNEL: { label: "DNA Kernel", color: "#a78bfa", bg: "rgba(167,139,250,0.09)" },
  AGENT_1: { label: "Agent 1 · Analyst", color: "#34d399", bg: "rgba(52,211,153,0.07)" },
  AGENT_2: { label: "Agent 2 · Generator", color: "#f59e0b", bg: "rgba(245,158,11,0.07)" },
  USER: { label: "You", color: "#64748b", bg: "rgba(148,163,184,0.05)" },
};

function Badge({ role }) {
  const c = AGENT_CFG[role] || AGENT_CFG.KERNEL;
  return (
    <span style={{
      fontSize: "9px", fontFamily: "'Space Mono',monospace",
      color: c.color, background: c.bg,
      border: `1px solid ${c.color}22`,
      padding: "2px 7px", borderRadius: "3px",
      letterSpacing: "0.1em", textTransform: "uppercase", userSelect: "none",
    }}>{c.label}</span>
  );
}

function FileChip({ f, onRemove }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: "6px",
      background: "rgba(255,255,255,0.04)",
      border: "1px solid rgba(255,255,255,0.07)",
      borderRadius: "6px", padding: "4px 8px 4px 6px",
      fontSize: "10px", color: "#64748b", maxWidth: "160px",
    }}>
      {f.isImage ? (
        <img src={`data:${f.mimeType};base64,${f.data}`} alt={f.name}
          style={{ width: "22px", height: "22px", objectFit: "cover", borderRadius: "3px", flexShrink: 0 }} />
      ) : (
        <div style={{
          width: "22px", height: "22px", borderRadius: "3px",
          background: "rgba(167,139,250,0.12)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: "7px", color: "#a78bfa", fontFamily: "'Space Mono',monospace", flexShrink: 0,
        }}>
          {f.name.split(".").pop().toUpperCase().slice(0, 3)}
        </div>
      )}
      <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", flex: 1, fontSize: "10px" }}>{f.name}</span>
      <span style={{ fontSize: "9px", color: "#334155", flexShrink: 0 }}>{f.size}</span>
      {onRemove && (
        <button onClick={onRemove} style={{
          background: "none", border: "none", cursor: "pointer",
          color: "#475569", fontSize: "13px", lineHeight: 1, padding: "0 0 0 2px", flexShrink: 0,
        }}>×</button>
      )}
    </div>
  );
}

function Message({ msg }) {
  const isUser = msg.role === "USER";
  return (
    <div style={{
      display: "flex", flexDirection: "column",
      alignItems: isUser ? "flex-end" : "flex-start",
      marginBottom: "20px", gap: "5px",
      animation: "fadeUp 0.22s ease forwards",
    }}>
      <Badge role={msg.role} />
      <div style={{
        maxWidth: "min(85%,620px)",
        background: isUser ? "rgba(167,139,250,0.06)" : "rgba(10,15,28,0.8)",
        border: `1px solid ${isUser ? "rgba(167,139,250,0.15)" : "rgba(255,255,255,0.05)"}`,
        borderRadius: isUser ? "13px 3px 13px 13px" : "3px 13px 13px 13px",
        padding: "11px 15px",
        fontSize: "13px", lineHeight: "1.8",
        color: "#d1daf0",
        fontFamily: "'IBM Plex Sans',sans-serif",
        whiteSpace: "pre-wrap", wordBreak: "break-word",
      }}>
        {msg.attachments?.length > 0 && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: "6px", marginBottom: "10px" }}>
            {msg.attachments.map((f, i) => <FileChip key={i} f={f} />)}
          </div>
        )}
        {msg.content}
      </div>
    </div>
  );
}

function Dots({ agent }) {
  const c = AGENT_CFG[agent] || AGENT_CFG.KERNEL;
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start", gap: "5px", marginBottom: "16px" }}>
      <Badge role={agent} />
      <div style={{
        background: "rgba(10,15,28,0.8)", border: "1px solid rgba(255,255,255,0.05)",
        borderRadius: "3px 13px 13px 13px", padding: "11px 16px",
        display: "flex", gap: "5px", alignItems: "center",
      }}>
        {[0, 1, 2].map(i => (
          <div key={i} style={{
            width: "5px", height: "5px", borderRadius: "50%", background: c.color,
            animation: `dot 1.1s ease-in-out ${i * 0.18}s infinite`,
          }} />
        ))}
      </div>
    </div>
  );
}

function PipelineRow({ label, desc, color, active }) {
  return (
    <div style={{ display: "flex", alignItems: "flex-start", gap: "10px", opacity: active ? 1 : 0.45, transition: "opacity 0.3s" }}>
      <div style={{
        width: "6px", height: "6px", borderRadius: "50%", background: color,
        marginTop: "4px", flexShrink: 0,
        boxShadow: active ? `0 0 7px ${color}` : "none", transition: "box-shadow 0.3s",
      }} />
      <div>
        <div style={{ fontSize: "11px", color: "#94a3b8", fontWeight: 500 }}>{label}</div>
        <div style={{ fontSize: "10px", color: "#374151", marginTop: "1px" }}>{desc}</div>
      </div>
    </div>
  );
}


const PROVIDERS = [
  { id: "claude", label: "Claude" },
  { id: "openai", label: "OpenAI" },
  { id: "gemini", label: "Gemini" },
  { id: "local", label: "Ollama / Local" },
];

function TinyButton({ active, children, onClick, disabled }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{
      border: `1px solid ${active ? "rgba(167,139,250,0.42)" : "rgba(255,255,255,0.07)"}`,
      background: active ? "rgba(167,139,250,0.10)" : "rgba(255,255,255,0.035)",
      color: active ? "#c4b5fd" : "#64748b",
      borderRadius: "7px",
      padding: "7px 9px",
      fontSize: "9px",
      fontFamily: "'Space Mono',monospace",
      cursor: disabled ? "default" : "pointer",
      opacity: disabled ? 0.45 : 1,
    }}>{children}</button>
  );
}

function ProviderSwitcher({ provider, setProvider, apiKey, setApiKey, localEndpoint, setLocalEndpoint, localModel, setLocalModel }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "9px" }}>
      <div style={{ fontFamily: "'Space Mono',monospace", fontSize: "8px", color: "#1e293b", letterSpacing: "0.18em", textTransform: "uppercase" }}>
        API Switch
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px" }}>
        {PROVIDERS.map(p => (
          <TinyButton key={p.id} active={provider === p.id} onClick={() => setProvider(p.id)}>
            {p.label}
          </TinyButton>
        ))}
      </div>
      {provider === "local" ? (
        <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: "6px" }}>
          <input value={localEndpoint} onChange={(e) => setLocalEndpoint(e.target.value)}
            placeholder="Ollama endpoint"
            style={{
              width: "100%", background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)",
              borderRadius: "7px", color: "#94a3b8", padding: "8px 9px", fontSize: "10px",
              fontFamily: "'Space Mono',monospace",
            }} />
          <input value={localModel} onChange={(e) => setLocalModel(e.target.value)}
            placeholder="Ollama model, e.g. llama3.1"
            style={{
              width: "100%", background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)",
              borderRadius: "7px", color: "#94a3b8", padding: "8px 9px", fontSize: "10px",
              fontFamily: "'Space Mono',monospace",
            }} />
        </div>
      ) : (
        <input value={apiKey} onChange={(e) => setApiKey(e.target.value)}
          placeholder="Ephemeral key / proxy token"
          type="password"
          style={{
            width: "100%", background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)",
            borderRadius: "7px", color: "#94a3b8", padding: "8px 9px", fontSize: "10px",
            fontFamily: "'Space Mono',monospace",
          }} />
      )}
      <p style={{ fontSize: "9px", color: "#334155", lineHeight: 1.7 }}>
        Cloud providers are routed through /api/llm. Local LLM uses the endpoint above.
      </p>
    </div>
  );
}


function SimSlider({ label, value, min, max, step, onChange, suffix = "" }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: "4px" }}>
      <span style={{ display: "flex", justifyContent: "space-between", gap: "8px", fontSize: "9px", color: "#64748b" }}>
        <b style={{ fontWeight: 500 }}>{label}</b>
        <em style={{ color: "#38bdf8", fontStyle: "normal", fontFamily: "'Space Mono',monospace" }}>{Number(value).toFixed(2)}{suffix}</em>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        style={{ width: "100%", accentColor: "#38bdf8" }}
      />
    </label>
  );
}

function TelemetryCell({ label, value, tone = "#38bdf8" }) {
  return (
    <div style={{
      border: "1px solid rgba(255,255,255,0.06)",
      background: "rgba(6,9,15,0.50)",
      borderRadius: "7px",
      padding: "7px 8px",
    }}>
      <div style={{ fontSize: "8px", color: "#334155", fontFamily: "'Space Mono',monospace", letterSpacing: "0.12em", textTransform: "uppercase" }}>{label}</div>
      <div style={{ marginTop: "3px", color: tone, fontSize: "12px", fontFamily: "'Space Mono',monospace" }}>{value}</div>
    </div>
  );
}


function parseTelemetryInsight(raw) {
  if (!raw || typeof raw !== "string") {
    return { status: "watch", severity: 0.4, summary: "No analyzer response.", dominantCause: "balanced", recommendedPatch: {}, telemetryRead: {} };
  }

  try {
    const jsonMatch = raw.match(/\{[\s\S]*\}/);
    const parsed = JSON.parse(jsonMatch ? jsonMatch[0] : raw);
    return {
      status: parsed.status || "watch",
      severity: Number.isFinite(Number(parsed.severity)) ? Number(parsed.severity) : 0.4,
      summary: parsed.summary || "Telemetry analyzed.",
      dominantCause: parsed.dominantCause || "balanced",
      recommendedPatch: parsed.recommendedPatch || {},
      telemetryRead: parsed.telemetryRead || {},
    };
  } catch {
    return {
      status: "watch",
      severity: 0.5,
      summary: raw.slice(0, 160),
      dominantCause: "balanced",
      recommendedPatch: {},
      telemetryRead: {},
    };
  }
}

function Agent3Panel({ active, setActive, open, setOpen, simParams, setSimParams, provider, apiKey, localEndpoint, localModel }) {
  const [llmTelemetryEnabled, setLlmTelemetryEnabled] = useState(false);
  const [llmStatus, setLlmStatus] = useState("idle");
  const [llmInsight, setLlmInsight] = useState(null);
  const lastTelemetryFingerprintRef = useRef("");

  const setParam = (key, value) => setSimParams(prev => ({ ...prev, [key]: value }));

  const telemetry = (() => {
    const exposure = simParams.lightLux * (simParams.shutterMs / 1000) * simParams.iris;
    const blurPx = (simParams.focalMm / Math.max(simParams.distanceM, 0.75)) * simParams.motionMps * (simParams.shutterMs / 1000) * 220;
    const burnRisk = Math.max(0, Math.min(1, (exposure / 1200) * (1 - simParams.antiBurn)));
    const stability = Math.max(0, Math.min(1, Math.exp(-Math.abs(simParams.ssf - simParams.antiBurn) * 1.85) * (1 - burnRisk * 0.35)));
    const flowConfidence = Math.max(0, Math.min(1, (blurPx / 18) * stability * (0.7 + 0.3 * simParams.motionMps / 10)));
    return { exposure, blurPx, burnRisk, stability, flowConfidence };
  })();

  useEffect(() => {
    if (!active || !llmTelemetryEnabled) return;

    const packet = {
      contract: "Agent 3 is telemetry-only: no chat, no task, no production.",
      provider,
      params: simParams,
      telemetry,
    };

    const fingerprint = JSON.stringify({
      provider,
      p: {
        shutterMs: Math.round(simParams.shutterMs),
        lightLux: Math.round(simParams.lightLux),
        iris: Number(simParams.iris).toFixed(2),
        motionMps: Number(simParams.motionMps).toFixed(1),
        focalMm: Math.round(simParams.focalMm),
        distanceM: Number(simParams.distanceM).toFixed(1),
        ssf: Number(simParams.ssf).toFixed(2),
        antiBurn: Number(simParams.antiBurn).toFixed(2),
      },
      t: {
        exposure: telemetry.exposure.toFixed(1),
        blurPx: telemetry.blurPx.toFixed(2),
        burnRisk: telemetry.burnRisk.toFixed(3),
        flowConfidence: telemetry.flowConfidence.toFixed(3),
      },
    });

    if (lastTelemetryFingerprintRef.current === fingerprint) return;

    let cancelled = false;
    const delay = provider === "local" ? 450 : 1200;

    const timer = setTimeout(async () => {
      lastTelemetryFingerprintRef.current = fingerprint;
      setLlmStatus("analyzing");

      const raw = await callLLM({
        provider,
        apiKey,
        localEndpoint,
        localModel,
        systemPrompt: AGENT_3_TELEMETRY_PROMPT,
        messages: [{ role: "user", content: JSON.stringify(packet) }],
      });

      if (cancelled) return;

      if (typeof raw === "string" && (raw.startsWith("API Error:") || raw.startsWith("Network error:"))) {
        setLlmStatus("error");
        setLlmInsight({ status: "watch", severity: 0.4, summary: raw, dominantCause: "balanced", recommendedPatch: {}, telemetryRead: {} });
        return;
      }

      setLlmInsight(parseTelemetryInsight(raw));
      setLlmStatus("ready");
    }, delay);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [
    active,
    llmTelemetryEnabled,
    provider,
    apiKey,
    localEndpoint,
    localModel,
    simParams,
    telemetry.exposure,
    telemetry.blurPx,
    telemetry.burnRisk,
    telemetry.stability,
    telemetry.flowConfidence,
  ]);

  const insightTone =
    llmInsight?.status === "risk" ? "#f59e0b" :
    llmInsight?.status === "stable" ? "#22c55e" :
    "#38bdf8";

  return (
    <div style={{
      border: "1px solid rgba(56,189,248,0.16)",
      background: active ? "rgba(56,189,248,0.055)" : "rgba(255,255,255,0.025)",
      borderRadius: "10px",
      padding: "11px",
      display: "flex",
      flexDirection: "column",
      gap: "10px",
    }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "10px" }}>
        <div>
          <div style={{ fontFamily: "'Space Mono',monospace", fontSize: "8px", color: "#38bdf8", letterSpacing: "0.16em", textTransform: "uppercase" }}>
            Agent 3 · Real-Time Simulation Panel
          </div>
          <div style={{ fontSize: "10px", color: "#475569", marginTop: "3px", lineHeight: 1.6 }}>
            LLM-supported telemetry analyzer. No chat. No task. No production.
          </div>
        </div>
        <TinyButton active={active} onClick={() => { setActive(!active); if (!active) setOpen(true); }}>
          {active ? "Active" : "Activate"}
        </TinyButton>
      </div>

      {active && (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px" }}>
            <TinyButton active={open} onClick={() => setOpen(v => !v)}>Telemetry</TinyButton>
            <TinyButton active={llmTelemetryEnabled} onClick={() => setLlmTelemetryEnabled(v => !v)}>
              LLM Analyzer
            </TinyButton>
            <TinyButton active={false} onClick={() => setSimParams({
              shutterMs: 333,
              lightLux: 2200,
              iris: 0.84,
              motionMps: 5.8,
              focalMm: 64,
              distanceM: 56,
              ssf: 0.68,
              antiBurn: 0.70,
            })}>Reset</TinyButton>
            <TinyButton active={false} disabled>
              {llmTelemetryEnabled ? llmStatus : "LLM off"}
            </TinyButton>
          </div>

          {open && (
            <div style={{
              border: "1px solid rgba(56,189,248,0.10)",
              background: "rgba(6,9,15,0.55)",
              borderRadius: "8px",
              padding: "10px",
              display: "flex",
              flexDirection: "column",
              gap: "10px",
            }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "7px" }}>
                <TelemetryCell label="Exposure" value={telemetry.exposure.toFixed(1)} />
                <TelemetryCell label="Blur px" value={telemetry.blurPx.toFixed(2)} />
                <TelemetryCell label="Burn risk" value={telemetry.burnRisk.toFixed(3)} tone={telemetry.burnRisk > 0.55 ? "#f59e0b" : "#38bdf8"} />
                <TelemetryCell label="Flow conf." value={telemetry.flowConfidence.toFixed(3)} />
              </div>

              {llmTelemetryEnabled && (
                <div style={{
                  border: `1px solid ${insightTone}33`,
                  background: "rgba(2,6,23,0.48)",
                  borderRadius: "8px",
                  padding: "9px",
                  display: "flex",
                  flexDirection: "column",
                  gap: "7px",
                }}>
                  <div style={{ display: "flex", justifyContent: "space-between", gap: "8px", alignItems: "center" }}>
                    <span style={{ fontFamily: "'Space Mono',monospace", color: insightTone, fontSize: "9px", letterSpacing: "0.12em", textTransform: "uppercase" }}>
                      LLM Telemetry Read
                    </span>
                    <span style={{ fontFamily: "'Space Mono',monospace", color: "#64748b", fontSize: "9px" }}>
                      {provider === "local" ? `local:${localModel || "model"}` : provider}
                    </span>
                  </div>

                  <div style={{ fontSize: "10px", color: "#94a3b8", lineHeight: 1.7 }}>
                    {llmInsight?.summary || (llmStatus === "analyzing" ? "Analyzing parameter telemetry..." : "Waiting for parameter movement.")}
                  </div>

                  {llmInsight && (
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "7px" }}>
                      <TelemetryCell label="Status" value={llmInsight.status || "watch"} tone={insightTone} />
                      <TelemetryCell label="Cause" value={llmInsight.dominantCause || "balanced"} tone={insightTone} />
                    </div>
                  )}

                  {llmInsight?.recommendedPatch && (
                    <div style={{ fontSize: "9px", color: "#475569", lineHeight: 1.7, fontFamily: "'Space Mono',monospace" }}>
                      patch: {JSON.stringify(llmInsight.recommendedPatch)}
                    </div>
                  )}
                </div>
              )}

              <SimSlider label="Shutter" value={simParams.shutterMs} min={8} max={700} step={1} suffix="ms" onChange={(v) => setParam("shutterMs", v)} />
              <SimSlider label="Light" value={simParams.lightLux} min={50} max={10000} step={10} suffix="lx" onChange={(v) => setParam("lightLux", v)} />
              <SimSlider label="Iris" value={simParams.iris} min={0.05} max={1} step={0.01} onChange={(v) => setParam("iris", v)} />
              <SimSlider label="Motion" value={simParams.motionMps} min={0.1} max={20} step={0.1} suffix="m/s" onChange={(v) => setParam("motionMps", v)} />
              <SimSlider label="Focal" value={simParams.focalMm} min={12} max={120} step={1} suffix="mm" onChange={(v) => setParam("focalMm", v)} />
              <SimSlider label="Distance" value={simParams.distanceM} min={5} max={100} step={0.5} suffix="m" onChange={(v) => setParam("distanceM", v)} />
              <SimSlider label="SSF" value={simParams.ssf} min={0} max={1} step={0.01} onChange={(v) => setParam("ssf", v)} />
              <SimSlider label="Anti-burn" value={simParams.antiBurn} min={0} max={1} step={0.01} onChange={(v) => setParam("antiBurn", v)} />

              <div style={{ fontSize: "9px", color: "#334155", lineHeight: 1.7 }}>
                Agent 3 can use Ollama/API calls as a telemetry analyzer only. Output is structured diagnostics, not chat.
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default function AbstraEngine() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [files, setFiles] = useState([]);
  const [processing, setProcessing] = useState(false);
  const [activeAgent, setActiveAgent] = useState(null);
  const [history, setHistory] = useState([]);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const [isMobile, setIsMobile] = useState(() => typeof window !== "undefined" ? window.innerWidth < 768 : false);
  const [provider, setProvider] = useState("claude");
  const [apiKey, setApiKey] = useState("");
  const [localEndpoint, setLocalEndpoint] = useState("http://localhost:11434/api/chat");
  const [localModel, setLocalModel] = useState("llama3.1");
  const [agent3Active, setAgent3Active] = useState(false);
  const [agent3PanelOpen, setAgent3PanelOpen] = useState(false);
  const [simParams, setSimParams] = useState({
    shutterMs: 333,
    lightLux: 2200,
    iris: 0.84,
    motionMps: 5.8,
    focalMm: 64,
    distanceM: 56,
    ssf: 0.68,
    antiBurn: 0.70,
  });

  const bottomRef = useRef(null);
  const textareaRef = useRef(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const handler = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener("resize", handler);
    return () => window.removeEventListener("resize", handler);
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, processing]);

  const addMsg = (role, content, attachments = []) =>
    setMessages(prev => [...prev, { id: Date.now() + Math.random(), role, content, attachments }]);

  const buildContent = (text, atts) => {
    if (!atts?.length) return text;
    const imgs = atts.filter(a => a.isImage);
    if (!imgs.length) {
      return atts.map(a => `[Attached: ${a.name}]`).join(" ") + "\n\n" + text;
    }
    const parts = imgs.map(a => ({
      type: "image",
      source: { type: "base64", media_type: a.mimeType, data: a.data },
    }));
    const nonImgNote = atts.filter(a => !a.isImage).map(a => `[Attached: ${a.name}]`).join(" ");
    parts.push({ type: "text", text: (nonImgNote ? nonImgNote + "\n\n" : "") + text });
    return parts;
  };

  const handleSend = async () => {
    if ((!input.trim() && !files.length) || processing) return;
    const userText = input.trim() || "(see attached files)";
    const atts = [...files];
    setInput("");
    setFiles([]);
    if (textareaRef.current) textareaRef.current.style.height = "auto";
    if (isMobile) setSidebarOpen(false);

    addMsg("USER", userText, atts);
    setProcessing(true);

    const userContent = buildContent(userText, atts);
    const newHistory = [...history, { role: "user", content: userContent }];



    try {
      setActiveAgent("KERNEL");
      const kernelRaw = await callLLM({ provider, apiKey, localEndpoint, localModel, systemPrompt: DNA_KERNEL_PROMPT, messages: newHistory });
      const routing = parseRouting(kernelRaw);
      addMsg("KERNEL", stripTags(kernelRaw));
      const updatedHistory = [...newHistory, { role: "assistant", content: kernelRaw }];
      setHistory(updatedHistory);

      if (routing === "AGENT_1" || routing === "PIPELINE") {
        setActiveAgent("AGENT_1");
        const a1Content = buildContent(userText, atts);
        const a1Res = await callLLM({ provider, apiKey, localEndpoint, localModel, systemPrompt: AGENT_1_PROMPT, messages: [{ role: "user", content: a1Content }] });
        addMsg("AGENT_1", a1Res);

        if (routing === "PIPELINE") {
          setActiveAgent("AGENT_2");
          const a2Res = await callLLM({ provider, apiKey, localEndpoint, localModel, systemPrompt: AGENT_2_PROMPT, messages: [{
            role: "user",
            content: "Generate based on this validated context:\n\n" + a1Res,
          }] });
          addMsg("AGENT_2", a2Res);
        }
      } else if (routing === "AGENT_2") {
        setActiveAgent("AGENT_2");
        const a2Res = await callLLM({ provider, apiKey, localEndpoint, localModel, systemPrompt: AGENT_2_PROMPT, messages: [{
          role: "user",
          content: "User request (validated by kernel):\n\n" + userText,
        }] });
        addMsg("AGENT_2", a2Res);
      }
    } catch (e) {
      addMsg("KERNEL", "System error: " + e.message);
    } finally {
      setProcessing(false);
      setActiveAgent(null);
    }
  };

  const handleKey = (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  const handleFiles = useCallback(async (rawFiles) => {
    const arr = Array.from(rawFiles).slice(0, 5);
    const processed = await Promise.all(arr.map(async (f) => ({
      name: f.name,
      mimeType: f.type,
      size: formatBytes(f.size),
      isImage: isImageFile(f),
      data: await fileToBase64(f),
    })));
    setFiles(prev => [...prev, ...processed].slice(0, 5));
  }, []);

  const removeFile = (i) => setFiles(prev => prev.filter((_, idx) => idx !== i));

  const activeStep = activeAgent === "KERNEL" ? 0 : activeAgent === "AGENT_1" ? 1 : activeAgent === "AGENT_2" ? 2 : -1;

  const sidebarVisible = !isMobile || sidebarOpen;

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=IBM+Plex+Sans:wght@300;400;500&family=Syne:wght@700;800&display=swap');
        *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
        html,body{height:100%;background:#06090f;overflow:hidden}
        @keyframes fadeUp{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}
        @keyframes dot{0%,100%{opacity:.2;transform:scale(.72)}50%{opacity:1;transform:scale(1)}}
        ::-webkit-scrollbar{width:3px}
        ::-webkit-scrollbar-thumb{background:rgba(167,139,250,0.14);border-radius:2px}
        textarea{resize:none;outline:none}
        textarea::placeholder{color:#1e293b}
        button:focus{outline:none}
      `}</style>

      {/* Sidebar overlay on mobile */}
      {isMobile && sidebarOpen && (
        <div onClick={() => setSidebarOpen(false)} style={{
          position: "fixed", inset: 0, background: "rgba(0,0,0,0.55)",
          zIndex: 99, backdropFilter: "blur(2px)",
        }} />
      )}

      <div style={{ display: "flex", height: "100vh", background: "#06090f", color: "#d1daf0", overflow: "hidden", position: "relative" }}>

        {/* ── SIDEBAR ── */}
        {sidebarVisible && (
          <aside style={{
            width: "248px", minWidth: "248px",
            borderRight: "1px solid rgba(255,255,255,0.04)",
            padding: "26px 18px",
            display: "flex", flexDirection: "column", gap: "24px",
            background: "#070b16",
            overflowY: "auto",
            ...(isMobile ? {
              position: "fixed", left: 0, top: 0, bottom: 0,
              zIndex: 100, boxShadow: "4px 0 24px rgba(0,0,0,0.5)",
            } : {}),
          }}>
            <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
              <div>
                <div style={{ fontFamily: "'Syne',sans-serif", fontSize: "16px", fontWeight: 800, color: "#fff", letterSpacing: "-0.02em" }}>
                  ABSTRA
                </div>
                <div style={{ fontFamily: "'Space Mono',monospace", fontSize: "8px", color: "#a78bfa", letterSpacing: "0.22em", marginTop: "2px" }}>
                  MEMORY CORE ENGINE
                </div>
              </div>
              {isMobile && (
                <button onClick={() => setSidebarOpen(false)} style={{
                  background: "none", border: "none", cursor: "pointer",
                  color: "#475569", fontSize: "18px", lineHeight: 1, padding: "2px",
                }}>×</button>
              )}
            </div>

            <div style={{ height: "1px", background: "rgba(255,255,255,0.04)" }} />

            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
              <p style={{ fontSize: "11px", color: "#374151", lineHeight: 1.8, fontWeight: 300 }}>
                A structured workspace for dramatic analysis and controlled visual generation.
              </p>
              <p style={{ fontSize: "11px", color: "#374151", lineHeight: 1.8, fontWeight: 300 }}>
                Not a free-form chat. Clear context and files produce better results.
              </p>
            </div>

            <div style={{ height: "1px", background: "rgba(255,255,255,0.04)" }} />

            <ProviderSwitcher provider={provider} setProvider={setProvider} apiKey={apiKey} setApiKey={setApiKey} localEndpoint={localEndpoint} setLocalEndpoint={setLocalEndpoint} localModel={localModel} setLocalModel={setLocalModel} />

            <div style={{ height: "1px", background: "rgba(255,255,255,0.04)" }} />

            <Agent3Panel active={agent3Active} setActive={setAgent3Active} open={agent3PanelOpen} setOpen={setAgent3PanelOpen} simParams={simParams} setSimParams={setSimParams} provider={provider} apiKey={apiKey} localEndpoint={localEndpoint} localModel={localModel} />

            <div style={{ height: "1px", background: "rgba(255,255,255,0.04)" }} />

            <div style={{ display: "flex", flexDirection: "column", gap: "11px" }}>
              <div style={{ fontFamily: "'Space Mono',monospace", fontSize: "8px", color: "#1e293b", letterSpacing: "0.18em", textTransform: "uppercase", marginBottom: "2px" }}>
                Pipeline
              </div>
              <PipelineRow label="Kernel" desc="Orchestration · Validation" color="#a78bfa" active={activeStep === 0 || activeStep === -1} />
              <PipelineRow label="Agent 1 · Analysis" desc="Dramatic · Semiotic · Technical" color="#34d399" active={activeStep === 1} />
              <PipelineRow label="Agent 2 · Generation" desc="Prompt engineering · ComfyUI" color="#f59e0b" active={activeStep === 2} />
            </div>

            <div style={{ flex: 1 }} />

            <div style={{
              padding: "9px 11px",
              background: processing ? "rgba(167,139,250,0.05)" : "rgba(52,211,153,0.04)",
              border: `1px solid ${processing ? "rgba(167,139,250,0.1)" : "rgba(52,211,153,0.09)"}`,
              borderRadius: "7px",
              display: "flex", alignItems: "center", gap: "8px",
              transition: "all 0.3s",
            }}>
              <div style={{
                width: "5px", height: "5px", borderRadius: "50%",
                background: processing ? "#a78bfa" : "#34d399",
                boxShadow: `0 0 5px ${processing ? "#a78bfa" : "#34d399"}`,
                flexShrink: 0,
                animation: processing ? "dot 0.9s ease-in-out infinite" : "none",
              }} />
              <span style={{ fontSize: "9px", color: processing ? "#a78bfa" : "#34d399", fontFamily: "'Space Mono',monospace" }}>
                {processing
                  ? activeAgent === "KERNEL" ? "validating..."
                  : activeAgent === "AGENT_1" ? "analysing..."
                  : "generating..."
                  : "system ready"}
              </span>
            </div>
          </aside>
        )}

        {/* ── MAIN ── */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", minWidth: 0 }}>

          {/* Header */}
          <header style={{
            height: "50px", padding: "0 16px",
            borderBottom: "1px solid rgba(255,255,255,0.04)",
            display: "flex", alignItems: "center", justifyContent: "space-between",
            background: "#06090f", flexShrink: 0,
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
              {isMobile && (
                <button onClick={() => setSidebarOpen(v => !v)} style={{
                  width: "30px", height: "30px",
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.07)",
                  borderRadius: "6px", cursor: "pointer",
                  display: "flex", alignItems: "center", justifyContent: "center", color: "#64748b",
                }}>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="18" x2="21" y2="18" />
                  </svg>
                </button>
              )}
              {isMobile ? (
                <span style={{ fontFamily: "'Syne',sans-serif", fontSize: "13px", fontWeight: 800, color: "#fff" }}>ABSTRA</span>
              ) : (
                <span style={{ fontFamily: "'Space Mono',monospace", fontSize: "9px", color: "#1e293b", letterSpacing: "0.15em" }}>
                  DNA KERNEL · EXECUTION WORTHINESS GATE ACTIVE
                </span>
              )}
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: "7px" }}>
              <span style={{ fontFamily: "'Space Mono',monospace", fontSize: "9px", color: agent3Active ? "#38bdf8" : "#0f172a" }}>{agent3Active ? "AGENT 3 SIM ACTIVE" : "PIPELINE MODE"}</span>
              <span style={{ fontFamily: "'Space Mono',monospace", fontSize: "9px", color: "#0f172a" }}>v0.4-agent3-llm-telemetry</span>
            </div>
          </header>

          {/* Messages */}
          <div
            style={{ flex: 1, overflowY: "auto", padding: isMobile ? "16px 14px" : "24px 22px", position: "relative" }}
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => { e.preventDefault(); setDragOver(false); handleFiles(e.dataTransfer.files); }}
          >
            {dragOver && (
              <div style={{
                position: "fixed", inset: 0, zIndex: 50,
                background: "rgba(6,9,15,0.88)",
                display: "flex", alignItems: "center", justifyContent: "center",
                border: "2px dashed rgba(167,139,250,0.35)",
                pointerEvents: "none",
              }}>
                <div style={{ textAlign: "center", color: "#a78bfa", fontFamily: "'Space Mono',monospace", fontSize: "11px" }}>
                  <div style={{ fontSize: "28px", marginBottom: "8px" }}>⬇</div>
                  Drop files to attach
                </div>
              </div>
            )}

            {messages.length === 0 ? (
              <div style={{
                height: "100%", display: "flex", flexDirection: "column",
                alignItems: "center", justifyContent: "center",
                gap: "10px", opacity: 0.3, userSelect: "none",
              }}>
                <div style={{ fontFamily: "'Syne',sans-serif", fontSize: isMobile ? "28px" : "34px", fontWeight: 800, color: "#fff", letterSpacing: "-0.04em" }}>
                  ABSTRA
                </div>
                <div style={{ fontFamily: "'Space Mono',monospace", fontSize: "8px", color: "#a78bfa", letterSpacing: "0.28em" }}>
                  MEMORY CORE ENGINE
                </div>
                <div style={{ fontSize: "11px", color: "#1e293b", marginTop: "10px", textAlign: "center", maxWidth: "300px", lineHeight: 2 }}>
                  Submit a scene, text, image, or concept<br />to begin the analysis pipeline.
                </div>
              </div>
            ) : (
              messages.map(msg => <Message key={msg.id} msg={msg} />)
            )}
            {processing && <Dots agent={activeAgent || "KERNEL"} />}
            <div ref={bottomRef} />
          </div>

          {/* Input */}
          <div style={{
            borderTop: "1px solid rgba(255,255,255,0.04)",
            padding: isMobile ? "10px 12px 16px" : "12px 18px 18px",
            background: "#06090f", flexShrink: 0,
          }}>
            {/* Attached files preview */}
            {files.length > 0 && (
              <div style={{ display: "flex", flexWrap: "wrap", gap: "6px", marginBottom: "8px" }}>
                {files.map((f, i) => <FileChip key={i} f={f} onRemove={() => removeFile(i)} />)}
              </div>
            )}

            <div style={{
              display: "flex", gap: "8px", alignItems: "flex-end",
              background: "rgba(10,15,28,0.9)",
              border: `1px solid ${dragOver ? "rgba(167,139,250,0.3)" : "rgba(255,255,255,0.07)"}`,
              borderRadius: "11px", padding: "9px 11px",
              transition: "border-color 0.2s",
            }}>
              {/* Attach */}
              <button
                onClick={() => fileInputRef.current?.click()}
                title="Attach image or file"
                style={{
                  width: "30px", height: "30px",
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.07)",
                  borderRadius: "6px", cursor: "pointer",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  color: "#334155", flexShrink: 0, transition: "color 0.15s",
                }}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48" />
                </svg>
              </button>
              <input ref={fileInputRef} type="file" multiple
                accept="image/*,.pdf,.txt,.md,.json,.csv"
                style={{ display: "none" }}
                onChange={(e) => { handleFiles(e.target.files); e.target.value = ""; }}
              />

              {/* Textarea */}
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => {
                  setInput(e.target.value);
                  e.target.style.height = "auto";
                  e.target.style.height = Math.min(e.target.scrollHeight, 120) + "px";
                }}
                onKeyDown={handleKey}
                placeholder="Describe your scene, concept, or visual intent..."
                rows={1}
                style={{
                  flex: 1, background: "transparent", border: "none",
                  color: "#d1daf0", fontSize: isMobile ? "14px" : "13px",
                  fontFamily: "'IBM Plex Sans',sans-serif",
                  lineHeight: 1.65, maxHeight: "120px", overflowY: "auto",
                }}
              />

              {/* Send */}
              <button
                onClick={handleSend}
                disabled={processing || (!input.trim() && !files.length)}
                style={{
                  width: "30px", height: "30px", borderRadius: "6px",
                  background: (processing || (!input.trim() && !files.length))
                    ? "rgba(167,139,250,0.07)" : "rgba(167,139,250,0.82)",
                  border: "none",
                  cursor: (processing || (!input.trim() && !files.length)) ? "default" : "pointer",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  flexShrink: 0, transition: "all 0.2s",
                }}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none">
                  <path d="M5 12h14M12 5l7 7-7 7"
                    stroke={(processing || (!input.trim() && !files.length)) ? "#1e293b" : "#fff"}
                    strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
            </div>

            <div style={{
              marginTop: "6px", paddingLeft: "2px",
              display: "flex", justifyContent: "space-between",
              fontSize: "9px", color: "#0f172a", fontFamily: "'Space Mono',monospace",
            }}>
              <span>⏎ send · shift+⏎ newline</span>
              {!isMobile && <span>{agent3Active ? "agent 3 telemetry active · no LLM route" : "requests validated before execution"}</span>}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
