"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { Canvas, extend, useFrame } from "@react-three/fiber";
import { Html, OrbitControls, shaderMaterial } from "@react-three/drei";

/**
 * BasarLab_Pro.v2.2.simulation_config.jsx
 *
 * Professional architecture baseline + SimulationConfig contract adapter:
 *   Top Mode: DUO | GIANT
 *   GIANT Branch: Suppression | Blur-Map
 *
 * Contract:
 *   W(x,y,t) is one shared procedural world.
 *   DUO, GIANT/Suppression, and GIANT/Blur-Map project that world through isolated parameter spaces.
 * v2.2: adds official SimulationConfig JSON adapter for Agent 3 / ROCm / React viewer injection.
 */

const SCENES = [
  { id: 0, label: "Stadium / hard shadows" },
  { id: 1, label: "Aerial mountains / haze" },
  { id: 2, label: "Urban ground / sodium dust" },
];

const MOODS = [
  { id: 0, label: "Golden Backlight" },
  { id: 1, label: "Cold Haze Dawn" },
  { id: 2, label: "Urban Sodium Dust" },
  { id: 3, label: "Stadium Night Contrast" },
];

const DUO_PREVIEWS = [
  "FINAL DUO",
  "HIGH IRIS PATH",
  "LOW IRIS PATH",
  "SSF STABILITY",
  "CHROMA BRIDGE",
  "SHADOW BALANCE",
  "HIGHLIGHT BALANCE",
  "WORLD BEAUTY",
];

const SUPPRESSION_PREVIEWS = [
  "FINAL SUPPRESSION",
  "DILUTION FIELD",
  "IDENTITY RESIDUAL",
  "SCENE INTEGRITY",
  "IDENTITY LEAK",
  "HIGHLIGHT LEAK",
  "BLUR LENGTH",
  "PHOTOMETRIC STABILITY",
  "WORLD BEAUTY",
];

const BLUR_PREVIEWS = [
  "CINEMATIC FLOW",
  "FLOW FIELD",
  "TRACE CONTINUITY",
  "STATIC INTEGRITY",
  "ANTI-BURN FIELD",
  "FLOW CONFIDENCE",
  "TRACE ENERGY",
  "WORLD BEAUTY",
];

const DEFAULT_WORLD = {
  scene: 0,
  mood: 0,
  lightX: 0.82,
  lightY: 0.22,
  lightPower: 1.0,
  atmosphere: 0.72,
  shadowStrength: 0.82,
  motionAmount: 1.0,
  sceneDetail: 1.0,
  cinematicContrast: 1.0,
};

const DEFAULT_DUO = {
  preview: 0,
  irisHigh: 0.42,
  irisLow: 0.88,
  fastShutter: 1 / 250,
  slowShutter: 1 / 60,
  lightLux: 900,
  focalMm: 35,
  distanceM: 18,
  motionMps: 2.5,
  highlightKnee: 0.72,
  highlightShoulder: 0.92,
  lowRecovery: 0.62,
  ssfJ: 2.125,
  ssfStability: 0.68,
  chromaBridge: 0.55,
};

const DEFAULT_GIANT_SUPPRESSION = {
  preview: 0,
  shutter: 1 / 18,
  distanceM: 42,
  lightLux: 1800,
  iris: 0.72,
  motionMps: 4.0,
  focalMm: 38,
  dilution: 0.72,
  spreadPx: 18,
  identityThreshold: 0.36,
  flowLeakLimit: 0.24,
  preserveScene: 0.84,
  softness: 0.58,
  trailGain: 0.72,
  ambientFill: 0.22,
  highlightGuard: 0.64,
};

const DEFAULT_GIANT_BLUR = {
  preview: 0,
  shutter: 1 / 3,
  distanceM: 56,
  lightLux: 2200,
  iris: 0.84,
  motionMps: 5.8,
  focalMm: 64,
  flowGain: 0.88,
  tracePersistence: 0.84,
  streamSigmaPx: 24,
  mapContrast: 0.82,
  antiSsf: 0.70,
  burnGuard: 0.78,
  staticPreserve: 0.66,
  identityFade: 0.70,
  lateralSoftness: 0.28,
  colorFlow: 0.60,
};

const SIMULATION_CONFIG_VERSION = "basar.simulation-config.v1";

const MODE_TO_ROUTE = {
  DUO: { topMode: "duo", giantBranch: "suppression" },
  GIANT_SUPPRESSION: { topMode: "giant", giantBranch: "suppression" },
  GIANT_BLUR_MAP: { topMode: "giant", giantBranch: "blur" },
};

const ROUTE_TO_MODE = {
  "duo:suppression": "DUO",
  "duo:blur": "DUO",
  "giant:suppression": "GIANT_SUPPRESSION",
  "giant:blur": "GIANT_BLUR_MAP",
};

function clampNumber(value, fallback, min = -Infinity, max = Infinity) {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, n));
}

function pickNumberObject(source, defaults, limits = {}) {
  const out = { ...defaults };
  if (!source || typeof source !== "object") return out;

  for (const key of Object.keys(defaults)) {
    if (source[key] === undefined) continue;
    const [min, max] = limits[key] || [-Infinity, Infinity];
    out[key] = clampNumber(source[key], defaults[key], min, max);
  }
  return out;
}

export function normalizeSimulationConfig(config) {
  if (!config || typeof config !== "object") return null;

  const mode = MODE_TO_ROUTE[config.mode] ? config.mode : "DUO";
  const route = MODE_TO_ROUTE[mode];

  const world = pickNumberObject(config.world, DEFAULT_WORLD, {
    scene: [0, 2],
    mood: [0, 3],
    lightX: [0, 1],
    lightY: [0, 1],
    lightPower: [0, 3],
    atmosphere: [0, 2],
    shadowStrength: [0, 2],
    motionAmount: [0, 3],
    sceneDetail: [0, 3],
    cinematicContrast: [0, 2.5],
  });

  world.scene = Math.round(world.scene);
  world.mood = Math.round(world.mood);

  const params = config.params || {};

  return {
    schemaVersion: config.schemaVersion || SIMULATION_CONFIG_VERSION,
    source: config.source || "external",
    timestamp: config.timestamp || new Date().toISOString(),
    mode,
    previewIndex: Math.max(0, Math.round(clampNumber(config.previewIndex, 0, 0, 16))),
    route,
    world,
    params: {
      duo: pickNumberObject(params.duo, DEFAULT_DUO),
      suppression: pickNumberObject(params.suppression, DEFAULT_GIANT_SUPPRESSION),
      blur: pickNumberObject(params.blur, DEFAULT_GIANT_BLUR),
    },
    metadata: config.metadata || {},
  };
}

export function createSimulationConfigSnapshot({ world, duo, suppression, blur, topMode, giantBranch, activePreview }) {
  const mode = ROUTE_TO_MODE[`${topMode}:${giantBranch}`] || "DUO";
  return {
    schemaVersion: SIMULATION_CONFIG_VERSION,
    source: "basarlab-react-viewer",
    timestamp: new Date().toISOString(),
    mode,
    previewIndex: activePreview,
    world,
    params: { duo, suppression, blur },
    metadata: {
      contract: "Agent 3 is a real-time simulation backend, not an LLM.",
    },
  };
}

function applySimulationConfigToState(config, setters) {
  const normalized = normalizeSimulationConfig(config);
  if (!normalized) return null;

  setters.setWorld(normalized.world);
  setters.setDuo((prev) => ({ ...prev, ...normalized.params.duo, preview: normalized.mode === "DUO" ? normalized.previewIndex : prev.preview }));
  setters.setSuppression((prev) => ({
    ...prev,
    ...normalized.params.suppression,
    preview: normalized.mode === "GIANT_SUPPRESSION" ? normalized.previewIndex : prev.preview,
  }));
  setters.setBlur((prev) => ({
    ...prev,
    ...normalized.params.blur,
    preview: normalized.mode === "GIANT_BLUR_MAP" ? normalized.previewIndex : prev.preview,
  }));
  setters.setTopMode(normalized.route.topMode);
  setters.setGiantBranch(normalized.route.giantBranch);

  return normalized;
}

function buildTelemetrySnapshot({ world, duo, suppression, blur, topMode, giantBranch, activePreview }) {
  const mode = ROUTE_TO_MODE[`${topMode}:${giantBranch}`] || "DUO";
  const active = mode === "DUO" ? duo : mode === "GIANT_SUPPRESSION" ? suppression : blur;

  const shutter =
    mode === "DUO"
      ? Math.max(duo.fastShutter, duo.slowShutter)
      : active.shutter;
  const lightLux = mode === "DUO" ? duo.lightLux : active.lightLux;
  const iris = mode === "DUO" ? Math.max(duo.irisHigh, duo.irisLow) : active.iris;
  const focalMm = mode === "DUO" ? duo.focalMm : active.focalMm;
  const distanceM = mode === "DUO" ? duo.distanceM : active.distanceM;
  const motionMps = mode === "DUO" ? duo.motionMps : active.motionMps;

  const exposureSignal = lightLux * shutter * iris;
  const blurPx = (focalMm / Math.max(distanceM, 0.75)) * motionMps * shutter * 220;
  const burnRisk = Math.max(0, Math.min(1, exposureSignal / 1500));
  const simulationLoad = mode === "GIANT_BLUR_MAP" ? 0.82 : mode === "GIANT_SUPPRESSION" ? 0.54 : 0.28;

  return {
    schemaVersion: "basar.telemetry.v1",
    timestamp: new Date().toISOString(),
    mode,
    previewIndex: activePreview,
    exposureSignal,
    blurPx,
    burnRisk,
    simulationLoad,
    world,
  };
}

const ProMaterial = shaderMaterial(
  {
    uTime: 0,
    uTopMode: 0,
    uGiantBranch: 0,
    uPreview: 0,

    uScene: 0,
    uMood: 0,
    uLightX: 0.82,
    uLightY: 0.22,
    uLightPower: 1.0,
    uAtmosphere: 0.72,
    uShadowStrength: 0.82,
    uMotionAmount: 1.0,
    uSceneDetail: 1.0,
    uCinematicContrast: 1.0,

    uDuoIrisHigh: 0.42,
    uDuoIrisLow: 0.88,
    uDuoFastShutter: 1 / 250,
    uDuoSlowShutter: 1 / 60,
    uDuoLightLux: 900,
    uDuoFocalMm: 35,
    uDuoDistanceM: 18,
    uDuoMotionMps: 2.5,
    uDuoHighlightKnee: 0.72,
    uDuoHighlightShoulder: 0.92,
    uDuoLowRecovery: 0.62,
    uDuoSsfJ: 2.125,
    uDuoSsfStability: 0.68,
    uDuoChromaBridge: 0.55,

    uSupShutter: 1 / 18,
    uSupDistanceM: 42,
    uSupLightLux: 1800,
    uSupIris: 0.72,
    uSupMotionMps: 4,
    uSupFocalMm: 38,
    uSupDilution: 0.72,
    uSupSpreadPx: 18,
    uSupIdentityThreshold: 0.36,
    uSupFlowLeakLimit: 0.24,
    uSupPreserveScene: 0.84,
    uSupSoftness: 0.58,
    uSupTrailGain: 0.72,
    uSupAmbientFill: 0.22,
    uSupHighlightGuard: 0.64,

    uBlurShutter: 1 / 3,
    uBlurDistanceM: 56,
    uBlurLightLux: 2200,
    uBlurIris: 0.84,
    uBlurMotionMps: 5.8,
    uBlurFocalMm: 64,
    uBlurFlowGain: 0.88,
    uBlurTracePersistence: 0.84,
    uBlurStreamSigmaPx: 24,
    uBlurMapContrast: 0.82,
    uBlurAntiSsf: 0.70,
    uBlurBurnGuard: 0.78,
    uBlurStaticPreserve: 0.66,
    uBlurIdentityFade: 0.70,
    uBlurLateralSoftness: 0.28,
    uBlurColorFlow: 0.60,
  },
  /* glsl */ `
    varying vec2 vUv;
    uniform float uTime;

    void main() {
      vUv = uv;
      vec3 p = position;
      p.z += sin(uv.x * 3.14159265) * 0.05;
      p.z += sin(uTime * 0.28 + uv.y * 4.0) * 0.004;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
    }
  `,
  /* glsl */ `
    precision highp float;

    varying vec2 vUv;
    uniform float uTime;
    uniform float uTopMode;
    uniform float uGiantBranch;
    uniform float uPreview;

    uniform float uScene;
    uniform float uMood;
    uniform float uLightX;
    uniform float uLightY;
    uniform float uLightPower;
    uniform float uAtmosphere;
    uniform float uShadowStrength;
    uniform float uMotionAmount;
    uniform float uSceneDetail;
    uniform float uCinematicContrast;

    uniform float uDuoIrisHigh;
    uniform float uDuoIrisLow;
    uniform float uDuoFastShutter;
    uniform float uDuoSlowShutter;
    uniform float uDuoLightLux;
    uniform float uDuoFocalMm;
    uniform float uDuoDistanceM;
    uniform float uDuoMotionMps;
    uniform float uDuoHighlightKnee;
    uniform float uDuoHighlightShoulder;
    uniform float uDuoLowRecovery;
    uniform float uDuoSsfJ;
    uniform float uDuoSsfStability;
    uniform float uDuoChromaBridge;

    uniform float uSupShutter;
    uniform float uSupDistanceM;
    uniform float uSupLightLux;
    uniform float uSupIris;
    uniform float uSupMotionMps;
    uniform float uSupFocalMm;
    uniform float uSupDilution;
    uniform float uSupSpreadPx;
    uniform float uSupIdentityThreshold;
    uniform float uSupFlowLeakLimit;
    uniform float uSupPreserveScene;
    uniform float uSupSoftness;
    uniform float uSupTrailGain;
    uniform float uSupAmbientFill;
    uniform float uSupHighlightGuard;

    uniform float uBlurShutter;
    uniform float uBlurDistanceM;
    uniform float uBlurLightLux;
    uniform float uBlurIris;
    uniform float uBlurMotionMps;
    uniform float uBlurFocalMm;
    uniform float uBlurFlowGain;
    uniform float uBlurTracePersistence;
    uniform float uBlurStreamSigmaPx;
    uniform float uBlurMapContrast;
    uniform float uBlurAntiSsf;
    uniform float uBlurBurnGuard;
    uniform float uBlurStaticPreserve;
    uniform float uBlurIdentityFade;
    uniform float uBlurLateralSoftness;
    uniform float uBlurColorFlow;

    float PI = 3.14159265;

    float hash21(vec2 p) {
      p = fract(p * vec2(123.34, 456.21));
      p += dot(p, p + 45.32);
      return fract(p.x * p.y);
    }

    float noise(vec2 p) {
      vec2 i = floor(p);
      vec2 f = fract(p);
      float a = hash21(i);
      float b = hash21(i + vec2(1.0, 0.0));
      float c = hash21(i + vec2(0.0, 1.0));
      float d = hash21(i + vec2(1.0, 1.0));
      vec2 u = f * f * (3.0 - 2.0 * f);
      return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
    }

    float fbm(vec2 p) {
      float v = 0.0;
      float a = 0.5;
      for (int i = 0; i < 5; i++) {
        v += a * noise(p);
        p *= 2.03;
        a *= 0.5;
      }
      return v;
    }

    float luma(vec3 c) {
      return dot(c, vec3(0.299, 0.587, 0.114));
    }

    vec3 heat(float t) {
      t = clamp(t, 0.0, 1.0);
      vec3 a = vec3(0.035, 0.035, 0.12);
      vec3 b = vec3(0.05, 0.48, 1.0);
      vec3 c = vec3(1.00, 0.40, 0.08);
      vec3 d = vec3(1.00, 0.92, 0.42);
      if (t < 0.34) return mix(a, b, t / 0.34);
      if (t < 0.68) return mix(b, c, (t - 0.34) / 0.34);
      return mix(c, d, (t - 0.68) / 0.32);
    }

    vec3 moodWarm() {
      if (uMood < 0.5) return vec3(1.00, 0.78, 0.46);
      if (uMood < 1.5) return vec3(0.74, 0.86, 1.00);
      if (uMood < 2.5) return vec3(1.00, 0.62, 0.28);
      return vec3(0.80, 0.90, 1.00);
    }

    vec3 moodCool() {
      if (uMood < 0.5) return vec3(0.36, 0.52, 0.78);
      if (uMood < 1.5) return vec3(0.50, 0.72, 1.00);
      if (uMood < 2.5) return vec3(0.30, 0.36, 0.44);
      return vec3(0.08, 0.16, 0.28);
    }

    vec3 tone(vec3 c) {
      c = max(c, vec3(0.0));
      c = c / (c + vec3(0.64));
      c = pow(c, vec3(0.90));
      c = mix(vec3(luma(c)), c, 1.0 + 0.14 * uCinematicContrast);
      return clamp(c, 0.0, 1.0);
    }

    float agent(vec2 uv, vec2 p, float size) {
      vec2 d = uv - p;
      d.y *= 1.2;
      return exp(-dot(d, d) / max(size * size, 0.00001));
    }

    void stadium(vec2 uv, out vec3 base, out float shadow, out float haze, out float depth, out float motion) {
      float stripe = 0.5 + 0.5 * sin((uv.x * 16.0 + 0.12) * PI);
      base = mix(vec3(0.12, 0.36, 0.16), vec3(0.20, 0.58, 0.22), 0.30 + 0.42 * stripe);
      float line = max(1.0 - smoothstep(0.002, 0.010, abs(uv.x - 0.5)),
                       1.0 - smoothstep(0.004, 0.014, abs(length(uv - vec2(0.5)) - 0.105)));
      base = mix(base, vec3(0.92), line * 0.88);
      float band1 = 1.0 - smoothstep(0.12, 0.58, uv.x + uv.y * 0.72);
      float band2 = smoothstep(0.18, 0.22, uv.y) * (1.0 - smoothstep(0.42, 0.46, uv.y)) * (1.0 - smoothstep(0.22, 0.70, uv.x));
      shadow = clamp((band1 + 0.42 * band2) * uShadowStrength, 0.0, 1.0);
      haze = (1.0 - uv.y) * 0.10 * uAtmosphere;
      depth = mix(0.42, 0.88, uv.y);
      float t = fract(uTime * 0.05);
      motion = 0.0;
      motion += agent(uv, vec2(0.10 + 0.72 * t, 0.66 - 0.08 * t), 0.012);
      motion += agent(uv, vec2(0.22 + 0.52 * t, 0.46 + 0.06 * t), 0.010);
      motion += agent(uv, vec2(0.78 - 0.58 * t, 0.35 + 0.12 * t), 0.012);
      motion *= uMotionAmount;
    }

    void mountains(vec2 uv, out vec3 base, out float shadow, out float haze, out float depth, out float motion) {
      vec2 p = (uv - 0.5) * vec2(1.8, 1.2);
      float r1 = fbm(p * (3.0 + uSceneDetail * 1.4));
      float r2 = fbm((p + 9.0).yx * (4.2 + uSceneDetail));
      float terrain = 0.56 * r1 + 0.44 * r2;
      vec3 rock = mix(vec3(0.30, 0.28, 0.26), vec3(0.60, 0.53, 0.46), smoothstep(0.22, 0.9, terrain + uv.y * 0.35));
      vec3 moss = vec3(0.32, 0.38, 0.24);
      vec3 snow = vec3(0.92, 0.94, 0.98);
      base = mix(rock, moss, smoothstep(0.26, 0.55, terrain) * (1.0 - smoothstep(0.55, 0.76, uv.y)));
      base = mix(base, snow, smoothstep(0.72, 1.0, terrain + uv.y * 0.38));
      float lit = smoothstep(0.16, 0.78, uv.x + terrain * 0.16);
      shadow = clamp((1.0 - lit) * (0.45 + 0.45 * terrain) * uShadowStrength, 0.0, 1.0);
      haze = smoothstep(0.15, 1.0, uv.y) * (0.22 + 0.38 * fbm(p * 1.9 + 17.0)) * uAtmosphere;
      depth = clamp(0.22 + uv.y * 0.52 + terrain * 0.18, 0.0, 1.0);
      float t = fract(uTime * 0.035);
      motion = 0.12 * agent(uv, vec2(0.05 + 0.90 * t, 0.24 + 0.10 * sin(t * 6.28)), 0.010) * uMotionAmount;
    }

    void urban(vec2 uv, out vec3 base, out float shadow, out float haze, out float depth, out float motion) {
      float groundMask = smoothstep(0.52, 0.58, uv.y);
      vec3 wall = mix(vec3(0.80, 0.77, 0.70), vec3(0.56, 0.60, 0.64), uv.y);
      vec3 ground = mix(vec3(0.20, 0.21, 0.23), vec3(0.31, 0.30, 0.28), uv.y);
      base = mix(wall, ground, groundMask);
      float block = step(0.24, uv.x) * step(uv.x, 0.78) * (1.0 - smoothstep(0.50, 0.56, uv.y));
      base = mix(base, vec3(0.48, 0.35, 0.24), block * 0.30);
      float windows = step(0.0, sin(uv.x * 70.0)) * step(0.0, sin(uv.y * 44.0)) * block * 0.25;
      base += windows * vec3(0.18, 0.14, 0.07);
      shadow = clamp((1.0 - smoothstep(0.18, 0.78, uv.x * 0.72 + (1.0 - uv.y) * 0.95)) * uShadowStrength, 0.0, 1.0);
      float puddle = smoothstep(0.0, 0.11, 0.105 - length(uv - vec2(0.57, 0.81)));
      base = mix(base, vec3(0.14, 0.19, 0.24), puddle * 0.65);
      haze = (0.10 + smoothstep(0.0, 0.65, 1.0 - uv.y) * 0.12) * uAtmosphere;
      depth = mix(0.40, 0.90, uv.y) + block * 0.08;
      float t = fract(uTime * 0.045);
      motion = agent(uv, vec2(0.05 + 0.85 * t, 0.77), 0.012) * 0.65 * uMotionAmount;
      motion += agent(uv, vec2(0.82 - 0.70 * t, 0.62 + 0.03 * sin(t * 6.28)), 0.010) * 0.45 * uMotionAmount;
    }

    void world(vec2 uv, out vec3 beauty, out float lightField, out float shadow, out float haze, out float depth, out float motion, out float risk) {
      vec3 base;
      if (uScene < 0.5) stadium(uv, base, shadow, haze, depth, motion);
      else if (uScene < 1.5) mountains(uv, base, shadow, haze, depth, motion);
      else urban(uv, base, shadow, haze, depth, motion);

      vec2 lightPos = vec2(uLightX, uLightY);
      float d = distance(uv, lightPos);
      float core = exp(-d * d * 18.0);
      float halo = exp(-d * d * 3.4);
      lightField = clamp((core + 0.42 * halo) * uLightPower, 0.0, 1.4);
      risk = clamp(core * 0.85 + haze * 0.35 + luma(base) * lightField * 0.35, 0.0, 1.0);

      vec3 tint = mix(moodCool(), moodWarm(), clamp(core * 1.1 + 0.18, 0.0, 1.0));
      float wash = haze * (0.25 + 0.45 * halo);
      float illum = (0.32 + 0.96 * halo + 0.35 * core) * (1.0 - 0.82 * shadow);
      beauty = base * illum * tint + wash * vec3(1.0, 0.96, 0.88) + motion * vec3(0.95, 0.88, 0.70) * 0.25;
      beauty = clamp(beauty, 0.0, 1.0);
    }

    float shoulder(float x, float knee, float shoulderV) {
      if (x <= knee) return x;
      float t = clamp((x - knee) / max(shoulderV - knee, 0.001), 0.0, 1.0);
      return mix(x, knee + (1.0 - exp(-3.0 * t)) * (shoulderV - knee), 0.88);
    }

    vec3 duoProject(vec3 beauty, float shadow, float haze, float motion, float risk, out vec3 highPath, out vec3 lowPath, out float stability, out vec3 chroma, out float shadowBalance, out float highlightBalance) {
      float luxNorm = clamp(log2(uDuoLightLux + 1.0) / log2(20000.0), 0.0, 1.0);
      vec3 highSignal = beauty * uDuoIrisHigh * uDuoFastShutter * uDuoLightLux * 180.0;
      vec3 lowSignal = beauty * uDuoIrisLow * uDuoSlowShutter * uDuoLightLux * 180.0;
      highSignal = vec3(
        shoulder(highSignal.r, uDuoHighlightKnee, uDuoHighlightShoulder),
        shoulder(highSignal.g, uDuoHighlightKnee, uDuoHighlightShoulder),
        shoulder(highSignal.b, uDuoHighlightKnee, uDuoHighlightShoulder)
      );
      vec3 recoveredLow = lowSignal * mix(0.82, 1.26, uDuoLowRecovery);
      float shadowSelector = clamp(shadow * 0.58 + haze * 0.32 + (1.0 - luxNorm) * 0.22, 0.0, 1.0);
      float riskSelector = clamp(risk * 1.1, 0.0, 1.0);
      stability = exp(-abs(shadow - haze) * uDuoSsfJ) * mix(0.28, 1.0, uDuoSsfStability);
      chroma = mix(vec3(luma(beauty)), beauty, 0.55 + 0.40 * uDuoChromaBridge);
      highPath = tone(highSignal * (1.0 - 0.24 * riskSelector) * chroma);
      lowPath = tone(recoveredLow * mix(0.86, 1.08, stability));
      shadowBalance = clamp(shadowSelector, 0.0, 1.0);
      highlightBalance = clamp((1.0 - shadowSelector) * (0.65 + 0.35 * (1.0 - riskSelector)), 0.0, 1.0);
      vec3 finalDuo = mix(highPath, lowPath, shadowSelector * (0.70 + 0.30 * stability));
      finalDuo = mix(finalDuo, chroma, 0.10 + 0.14 * stability);
      return tone(finalDuo);
    }

    vec3 suppressionProject(vec2 uv, vec3 beauty, float shadow, float haze, float motion, float risk, out float dilution, out float identity, out float sceneIntegrity, out float identityLeak, out float highlightLeak, out float blurNorm, out float photo) {
      float exposure = uSupLightLux * uSupShutter * clamp(uSupIris, 0.05, 1.0);
      photo = clamp(log2(exposure + 1.0) / log2(1800.0), 0.0, 1.0) * (1.0 - risk * (1.0 - uSupHighlightGuard) * 0.75);
      float distNorm = clamp((uSupDistanceM - 5.0) / 75.0, 0.0, 1.0);
      float blurPx = (uSupFocalMm / max(uSupDistanceM, 0.75)) * uSupMotionMps * uSupShutter * 165.0 * (0.72 + 0.28 * uSupDilution);
      blurNorm = clamp(blurPx / 14.0, 0.0, 1.0);
      float collapse = 1.0 - exp(-blurPx / max(uSupSpreadPx, 1.0));
      dilution = clamp((0.42 * collapse + 0.28 * pow(distNorm, 0.82) + 0.18 * uSupDilution + 0.12 * photo) * motion, 0.0, 1.0);
      identity = clamp(motion * (1.0 - collapse) * (1.0 - distNorm * 0.55) * (1.0 - dilution * (0.65 + 0.25 * uSupTrailGain)), 0.0, 1.0);
      sceneIntegrity = clamp(uSupPreserveScene * (0.50 + 0.50 * photo) * (1.0 - 0.15 * dilution) + uSupAmbientFill * 0.08, 0.0, 1.0);
      identityLeak = clamp(max(identity - uSupFlowLeakLimit, 0.0), 0.0, 1.0);
      highlightLeak = clamp(max(risk - uSupHighlightGuard, 0.0) * 0.35, 0.0, 1.0);

      vec2 dir = normalize(vec2(1.0, -0.10 + 0.14 * sin(uTime * 0.45 + uv.y * 10.0)));
      vec3 acc = vec3(0.0);
      float wsum = 0.0;
      float trailLen = blurPx / 880.0 * (0.88 + 0.35 * uSupTrailGain);
      for (int i = -5; i <= 5; i++) {
        float fi = float(i);
        float w = exp(-(fi * fi) / (2.8 + 4.2 * uSupSoftness));
        vec2 su = clamp(uv + dir * fi * trailLen, vec2(0.0), vec2(1.0));
        vec3 b; float l; float s; float h; float d; float m; float r;
        world(su, b, l, s, h, d, m, r);
        acc += b * w;
        wsum += w;
      }
      vec3 trail = tone(acc / max(wsum, 0.0001));
      vec3 base = tone(beauty);
      return tone(mix(base, trail, smoothstep(uSupIdentityThreshold, 1.0, dilution) * (0.58 + 0.20 * uSupTrailGain)));
    }

    vec3 blurProject(vec2 uv, vec3 beauty, float shadow, float haze, float motion, float risk, out float flow, out float cont, out float staticI, out float antiBurn, out float confidence, out float energy, out float blurNorm, out float idFade) {
      float exposure = uBlurLightLux * uBlurShutter * clamp(uBlurIris, 0.05, 1.0);
      float lightNorm = clamp(log2(exposure + 1.0) / log2(3200.0), 0.0, 1.0);
      float sigmaNorm = clamp(uBlurStreamSigmaPx / 32.0, 0.05, 1.30);
      float distNorm = clamp((uBlurDistanceM - 5.0) / 85.0, 0.0, 1.0);
      float blurPx = (uBlurFocalMm / max(uBlurDistanceM, 0.75)) * uBlurMotionMps * uBlurShutter * 215.0;
      blurPx *= (0.74 + 0.26 * uBlurFlowGain) * (0.70 + 0.30 * sigmaNorm);
      blurNorm = clamp(blurPx / 20.0, 0.0, 1.0);

      float ssfReference = exp(-abs(shadow - haze) * 2.125);
      float ssfHighlightDelta = clamp(abs(risk - lightNorm), 0.0, 1.0);
      float ssfCorrector = exp(-ssfHighlightDelta * (1.35 + 1.25 * uBlurAntiSsf));
      float highlightStress = clamp(risk * (0.52 + 0.48 * lightNorm) + max(lightNorm - uBlurBurnGuard, 0.0) * 0.75, 0.0, 1.0);
      float smoothGuard = mix(ssfReference, ssfCorrector, 0.55);
      antiBurn = clamp((1.0 - highlightStress * (0.40 + 0.60 * uBlurAntiSsf)) * (0.62 + 0.38 * smoothGuard), 0.0, 1.0);

      vec2 dir = normalize(vec2(1.0, 0.16 * sin(uTime * 0.24 + uv.y * 12.0) - 0.11 * cos(uv.x * 8.0 + uTime * 0.11)));
      vec2 ortho = vec2(-dir.y, dir.x);
      float trailLen = (blurPx / 780.0) * (0.84 + 0.72 * uBlurTracePersistence);
      float sideLen = trailLen * (0.14 + 0.96 * uBlurLateralSoftness);

      vec3 accT = vec3(0.0);
      float wT = 0.0;
      float mT = 0.0;
      for (int i = -10; i <= 10; i++) {
        float fi = float(i);
        float w = exp(-(fi * fi) / (2.2 + 13.0 * sigmaNorm));
        vec2 su = clamp(uv + dir * fi * trailLen * (0.54 + 0.46 * sigmaNorm), vec2(0.0), vec2(1.0));
        vec3 b; float l; float s; float h; float d; float m; float r;
        world(su, b, l, s, h, d, m, r);
        accT += b * w;
        mT += m * w;
        wT += w;
      }
      vec3 trail = accT / max(wT, 0.0001);
      cont = clamp((mT / max(wT, 0.0001)) * (0.56 + 0.44 * blurNorm), 0.0, 1.0);

      vec3 accS = vec3(0.0);
      float wS = 0.0;
      for (int j = -4; j <= 4; j++) {
        float fj = float(j);
        float w = exp(-(fj * fj) / (1.8 + 7.5 * uBlurLateralSoftness));
        vec2 su = clamp(uv + ortho * fj * sideLen, vec2(0.0), vec2(1.0));
        vec3 b; float l; float s; float h; float d; float m; float r;
        world(su, b, l, s, h, d, m, r);
        accS += b * w;
        wS += w;
      }
      vec3 side = accS / max(wS, 0.0001);

      flow = clamp(blurNorm * (0.40 + 0.60 * motion) * (0.74 + 0.26 * uBlurFlowGain) * (0.76 + 0.24 * cont), 0.0, 1.0);
      idFade = clamp(flow * (0.44 + 0.56 * uBlurIdentityFade) * (0.68 + 0.32 * distNorm), 0.0, 1.0);
      confidence = clamp(flow * cont * antiBurn * (0.62 + 0.38 * lightNorm), 0.0, 1.0);
      staticI = clamp((1.0 - idFade * 0.48) * (0.44 + 0.56 * uBlurStaticPreserve) * (0.72 + 0.28 * antiBurn), 0.0, 1.0);

      vec3 base = tone(beauty);
      vec3 trace = tone(mix(trail, side, 0.18 + 0.34 * uBlurLateralSoftness));
      float tl = luma(trace);
      vec3 warm = vec3(1.00, 0.82, 0.64) * tl;
      vec3 cool = vec3(0.58, 0.80, 1.02) * tl;
      vec3 split = mix(cool, warm, clamp(0.28 + 0.42 * flow + 0.20 * haze + 0.10 * lightNorm, 0.0, 1.0));
      vec3 flowColor = mix(split, trace, 0.20 + 0.62 * uBlurColorFlow);
      flowColor *= (0.84 + 0.30 * uBlurMapContrast);
      flowColor *= antiBurn;
      energy = clamp(tl * flow * (0.72 + 0.28 * uBlurTracePersistence), 0.0, 1.0);
      vec3 glow = mix(vec3(0.66, 0.84, 1.0), vec3(1.0, 0.80, 0.62), 0.42 + 0.38 * flow) * smoothstep(0.26, 1.0, tl * flow) * 0.22 * antiBurn;
      vec3 outC = mix(base, flowColor, flow * (0.42 + 0.40 * uBlurFlowGain));
      outC += glow * (0.14 + 0.24 * cont);
      outC = mix(outC, base, staticI * (0.18 + 0.26 * uBlurStaticPreserve));
      outC *= 1.0 - 0.14 * smoothstep(0.42, 0.88, length(uv - 0.5));
      return tone(outC);
    }

    void main() {
      vec2 uv = vUv;
      vec3 beauty;
      float lightField;
      float shadow;
      float haze;
      float depth;
      float motion;
      float risk;
      world(uv, beauty, lightField, shadow, haze, depth, motion, risk);

      int p = int(uPreview + 0.5);
      vec3 color = tone(beauty);

      if (uTopMode < 0.5) {
        vec3 hi;
        vec3 lo;
        float stable;
        vec3 chroma;
        float shBal;
        float hiBal;
        vec3 duo = duoProject(beauty, shadow, haze, motion, risk, hi, lo, stable, chroma, shBal, hiBal);

        if (p == 0) color = duo;
        else if (p == 1) color = hi;
        else if (p == 2) color = lo;
        else if (p == 3) color = heat(stable);
        else if (p == 4) color = chroma;
        else if (p == 5) color = heat(shBal);
        else if (p == 6) color = heat(hiBal);
        else color = tone(beauty);
      } else if (uGiantBranch < 0.5) {
        float dil;
        float ident;
        float sceneI;
        float identityLeak;
        float highlightLeak;
        float supBlur;
        float photo;
        vec3 sup = suppressionProject(uv, beauty, shadow, haze, motion, risk, dil, ident, sceneI, identityLeak, highlightLeak, supBlur, photo);

        if (p == 0) color = sup;
        else if (p == 1) color = heat(dil);
        else if (p == 2) color = heat(ident);
        else if (p == 3) color = heat(sceneI);
        else if (p == 4) color = heat(identityLeak);
        else if (p == 5) color = heat(highlightLeak);
        else if (p == 6) color = heat(supBlur);
        else if (p == 7) color = heat(photo);
        else color = tone(beauty);
      } else {
        float flow;
        float cont;
        float staticI;
        float burn;
        float conf;
        float en;
        float blurN;
        float fade;
        vec3 blur = blurProject(uv, beauty, shadow, haze, motion, risk, flow, cont, staticI, burn, conf, en, blurN, fade);

        if (p == 0) color = blur;
        else if (p == 1) color = heat(flow);
        else if (p == 2) color = heat(cont);
        else if (p == 3) color = heat(staticI);
        else if (p == 4) color = heat(burn);
        else if (p == 5) color = heat(conf);
        else if (p == 6) color = heat(en);
        else color = tone(beauty);
      }

      gl_FragColor = vec4(color, 1.0);
    }
  `
);

extend({ ProMaterial });

function Chip({ active, disabled, children, onClick }) {
  return (
    <button className={active ? "chip active" : "chip"} disabled={disabled} onClick={disabled ? undefined : onClick}>
      {children}
    </button>
  );
}

function Slider({ label, value, min, max, step, onChange }) {
  return (
    <label className="control">
      <span><b>{label}</b><em>{Number(value).toFixed(3)}</em></span>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(parseFloat(e.target.value))} />
    </label>
  );
}

function Metric({ label, value, suffix = "" }) {
  return (
    <div className="metric">
      <b>{label}</b>
      <span>{value}{suffix}</span>
    </div>
  );
}

function PreviewSet({ topMode, giantBranch }) {
  if (topMode === "duo") return DUO_PREVIEWS;
  if (giantBranch === "suppression") return SUPPRESSION_PREVIEWS;
  return BLUR_PREVIEWS;
}

function Rig({ children, topMode, giantBranch }) {
  const ref = useRef();
  useFrame((state) => {
    if (!ref.current) return;
    const t = state.clock.getElapsedTime();
    const amp = topMode === "giant" && giantBranch === "blur" ? 0.055 : 0.032;
    ref.current.position.y = 0.16 + Math.sin(t * 0.28) * amp;
    ref.current.rotation.y = Math.sin(t * 0.13) * amp * 0.45;
  });
  return <group ref={ref} position={[0.5, 0.16, 0]}>{children}</group>;
}

function CoreScreen({ world, duo, suppression, blur, topMode, giantBranch, preview, label, large = false }) {
  const ref = useRef();
  useFrame((clock) => {
    if (ref.current) ref.current.uTime = clock.clock.getElapsedTime();
  });

  return (
    <group>
      <mesh position={[0, 0, 0.04]}>
        <planeGeometry args={[large ? 4.8 : 1.55, large ? 2.7 : 0.9, 96, 96]} />
        <proMaterial
          ref={ref}
          uTopMode={topMode === "giant" ? 1 : 0}
          uGiantBranch={giantBranch === "blur" ? 1 : 0}
          uPreview={preview}
          uScene={world.scene}
          uMood={world.mood}
          uLightX={world.lightX}
          uLightY={world.lightY}
          uLightPower={world.lightPower}
          uAtmosphere={world.atmosphere}
          uShadowStrength={world.shadowStrength}
          uMotionAmount={world.motionAmount}
          uSceneDetail={world.sceneDetail}
          uCinematicContrast={world.cinematicContrast}
          uDuoIrisHigh={duo.irisHigh}
          uDuoIrisLow={duo.irisLow}
          uDuoFastShutter={duo.fastShutter}
          uDuoSlowShutter={duo.slowShutter}
          uDuoLightLux={duo.lightLux}
          uDuoFocalMm={duo.focalMm}
          uDuoDistanceM={duo.distanceM}
          uDuoMotionMps={duo.motionMps}
          uDuoHighlightKnee={duo.highlightKnee}
          uDuoHighlightShoulder={duo.highlightShoulder}
          uDuoLowRecovery={duo.lowRecovery}
          uDuoSsfJ={duo.ssfJ}
          uDuoSsfStability={duo.ssfStability}
          uDuoChromaBridge={duo.chromaBridge}
          uSupShutter={suppression.shutter}
          uSupDistanceM={suppression.distanceM}
          uSupLightLux={suppression.lightLux}
          uSupIris={suppression.iris}
          uSupMotionMps={suppression.motionMps}
          uSupFocalMm={suppression.focalMm}
          uSupDilution={suppression.dilution}
          uSupSpreadPx={suppression.spreadPx}
          uSupIdentityThreshold={suppression.identityThreshold}
          uSupFlowLeakLimit={suppression.flowLeakLimit}
          uSupPreserveScene={suppression.preserveScene}
          uSupSoftness={suppression.softness}
          uSupTrailGain={suppression.trailGain}
          uSupAmbientFill={suppression.ambientFill}
          uSupHighlightGuard={suppression.highlightGuard}
          uBlurShutter={blur.shutter}
          uBlurDistanceM={blur.distanceM}
          uBlurLightLux={blur.lightLux}
          uBlurIris={blur.iris}
          uBlurMotionMps={blur.motionMps}
          uBlurFocalMm={blur.focalMm}
          uBlurFlowGain={blur.flowGain}
          uBlurTracePersistence={blur.tracePersistence}
          uBlurStreamSigmaPx={blur.streamSigmaPx}
          uBlurMapContrast={blur.mapContrast}
          uBlurAntiSsf={blur.antiSsf}
          uBlurBurnGuard={blur.burnGuard}
          uBlurStaticPreserve={blur.staticPreserve}
          uBlurIdentityFade={blur.identityFade}
          uBlurLateralSoftness={blur.lateralSoftness}
          uBlurColorFlow={blur.colorFlow}
        />
      </mesh>
      <Html center position={[0, large ? 1.48 : 0.58, 0.11]} style={{ pointerEvents: "none" }}>
        <div className="screen-label">{label}</div>
      </Html>
    </group>
  );
}

function Frame({ children, position, large = false }) {
  return (
    <group position={position}>
      <mesh>
        <boxGeometry args={[large ? 5.10 : 1.78, large ? 3.04 : 1.12, 0.08]} />
        <meshStandardMaterial color="#0c1118" roughness={0.65} metalness={0.24} />
      </mesh>
      {children}
    </group>
  );
}

function Stage({ world, duo, suppression, blur, topMode, giantBranch, activePreview }) {
  const previews = PreviewSet({ topMode, giantBranch });
  const side = [1, 2, 3, 4, 5, 6].filter((id) => id < previews.length);
  const scene = SCENES[world.scene]?.label || "Scene";
  const modeLabel = topMode === "duo" ? "DUO" : giantBranch === "suppression" ? "GIANT / SUPPRESSION" : "GIANT / BLUR-MAP";

  return (
    <section className="stage">
      <Canvas camera={{ position: [0.5, 0.95, 9.4], fov: 35 }} dpr={[1, 2]} gl={{ antialias: true, powerPreference: "high-performance" }}>
        <color attach="background" args={["#05070b"]} />
        <fog attach="fog" args={["#05070b", 10, 20]} />
        <ambientLight intensity={0.34} />
        <pointLight position={[0, 4, 5.2]} intensity={4.5} color="#9ac6ff" />
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1.76, 0]}>
          <planeGeometry args={[20, 20]} />
          <meshStandardMaterial color="#080b10" roughness={0.96} metalness={0.03} />
        </mesh>

        <Rig topMode={topMode} giantBranch={giantBranch}>
          <Frame position={[0, 0.34, 0]} large>
            <CoreScreen world={world} duo={duo} suppression={suppression} blur={blur} topMode={topMode} giantBranch={giantBranch} preview={activePreview} label={previews[activePreview] || "OUTPUT"} large />
          </Frame>
          {side.map((id, i) => (
            <Frame key={id} position={[-4.65 + i * 1.87, 1.52, -0.12]}>
              <CoreScreen world={world} duo={duo} suppression={suppression} blur={blur} topMode={topMode} giantBranch={giantBranch} preview={id} label={previews[id]} />
            </Frame>
          ))}
        </Rig>

        <OrbitControls enablePan={false} minDistance={5.2} maxDistance={16} minPolarAngle={0.42} maxPolarAngle={1.38} />
      </Canvas>

      <div className="hud">
        <div><strong>{modeLabel}</strong><span>active projection</span></div>
        <div><strong>{scene}</strong><span>{MOODS[world.mood]?.label}</span></div>
        <div><strong>{previews[activePreview] || "OUTPUT"}</strong><span>active output</span></div>
        <div><strong>Shared World</strong><span>W(x,y,t), isolated cores</span></div>
      </div>
    </section>
  );
}

function Controls({ topMode, setTopMode, giantBranch, setGiantBranch, world, setWorld, duo, setDuo, suppression, setSuppression, blur, setBlur }) {
  const previews = PreviewSet({ topMode, giantBranch });
  const activePreview = topMode === "duo" ? duo.preview : giantBranch === "suppression" ? suppression.preview : blur.preview;
  const setPreview = (id) => {
    if (topMode === "duo") setDuo((s) => ({ ...s, preview: id }));
    else if (giantBranch === "suppression") setSuppression((s) => ({ ...s, preview: id }));
    else setBlur((s) => ({ ...s, preview: id }));
  };

  const worldSet = (k, v) => setWorld((s) => ({ ...s, [k]: v }));
  const duoSet = (k, v) => setDuo((s) => ({ ...s, [k]: v }));
  const supSet = (k, v) => setSuppression((s) => ({ ...s, [k]: v }));
  const blurSet = (k, v) => setBlur((s) => ({ ...s, [k]: v }));

  return (
    <aside className="panel">
      <h1>Basar Pro v2.2</h1>
      <p className="desc" dir="rtl">
        نسخة v2.2: نفس معمارية DUO/GIANT، مع طبقة SimulationConfig رسمية. يمكن الآن حقن config موحّد من Abstra Engine أو Agent 3 backend لملء world/mode/params دون تحويل Agent 3 إلى LLM.
      </p>

      <section className="block">
        <div className="block-title">Top mode</div>
        <div className="chips">
          <Chip active={topMode === "duo"} onClick={() => setTopMode("duo")}>DUO</Chip>
          <Chip active={topMode === "giant"} onClick={() => setTopMode("giant")}>GIANT</Chip>
        </div>
      </section>

      {topMode === "giant" && (
        <section className="block">
          <div className="block-title">Giant branch</div>
          <div className="chips">
            <Chip active={giantBranch === "suppression"} onClick={() => setGiantBranch("suppression")}>Suppression</Chip>
            <Chip active={giantBranch === "blur"} onClick={() => setGiantBranch("blur")}>Blur-Map</Chip>
          </div>
        </section>
      )}

      <section className="block">
        <div className="block-title">Scene</div>
        <div className="chips">
          {SCENES.map((scene) => <Chip key={scene.id} active={world.scene === scene.id} onClick={() => worldSet("scene", scene.id)}>{scene.label}</Chip>)}
        </div>
      </section>

      <section className="block">
        <div className="block-title">Mood</div>
        <div className="chips">
          {MOODS.map((mood) => <Chip key={mood.id} active={world.mood === mood.id} onClick={() => worldSet("mood", mood.id)}>{mood.label}</Chip>)}
        </div>
      </section>

      <section className="block">
        <div className="block-title">Preview outputs</div>
        <div className="chips">
          {previews.map((label, id) => <Chip key={label} active={activePreview === id} onClick={() => setPreview(id)}>{label}</Chip>)}
        </div>
      </section>

      <section className="block">
        <div className="block-title">Shared world</div>
        <Slider label="Light X" value={world.lightX} min={0.02} max={0.98} step={0.01} onChange={(v) => worldSet("lightX", v)} />
        <Slider label="Light Y" value={world.lightY} min={0.02} max={0.98} step={0.01} onChange={(v) => worldSet("lightY", v)} />
        <Slider label="Light power" value={world.lightPower} min={0.1} max={2.2} step={0.02} onChange={(v) => worldSet("lightPower", v)} />
        <Slider label="Atmosphere" value={world.atmosphere} min={0} max={1.4} step={0.01} onChange={(v) => worldSet("atmosphere", v)} />
        <Slider label="Shadow strength" value={world.shadowStrength} min={0} max={1.5} step={0.01} onChange={(v) => worldSet("shadowStrength", v)} />
        <Slider label="Motion amount" value={world.motionAmount} min={0} max={2.0} step={0.01} onChange={(v) => worldSet("motionAmount", v)} />
      </section>

      {topMode === "duo" && (
        <>
          <section className="block">
            <div className="block-title">DUO optics</div>
            <Slider label="Iris high" value={duo.irisHigh} min={0.1} max={1} step={0.01} onChange={(v) => duoSet("irisHigh", v)} />
            <Slider label="Iris low" value={duo.irisLow} min={0.1} max={1} step={0.01} onChange={(v) => duoSet("irisLow", v)} />
            <Slider label="Fast shutter" value={duo.fastShutter} min={1 / 2000} max={1 / 30} step={0.0005} onChange={(v) => duoSet("fastShutter", v)} />
            <Slider label="Slow shutter" value={duo.slowShutter} min={1 / 250} max={1 / 8} step={0.001} onChange={(v) => duoSet("slowShutter", v)} />
            <Slider label="Light lux" value={duo.lightLux} min={10} max={5000} step={10} onChange={(v) => duoSet("lightLux", v)} />
            <Slider label="Focal mm" value={duo.focalMm} min={12} max={120} step={1} onChange={(v) => duoSet("focalMm", v)} />
            <Slider label="Distance m" value={duo.distanceM} min={1} max={100} step={0.5} onChange={(v) => duoSet("distanceM", v)} />
          </section>
        </>
      )}

      {topMode === "giant" && giantBranch === "suppression" && (
        <>
          <section className="block">
            <div className="block-title">Suppression presets</div>
            <div className="chips">
              <Chip onClick={() => setSuppression((s) => ({ ...s, shutter: 1 / 45, distanceM: 18, iris: 0.55, lightLux: 1200, focalMm: 28, spreadPx: 10, dilution: 0.48, preserveScene: 0.90 }))}>Near / mild</Chip>
              <Chip onClick={() => setSuppression({ ...DEFAULT_GIANT_SUPPRESSION })}>Balanced</Chip>
              <Chip onClick={() => setSuppression((s) => ({ ...s, shutter: 1 / 8, distanceM: 70, iris: 0.86, lightLux: 2600, focalMm: 55, spreadPx: 26, dilution: 0.88, preserveScene: 0.76 }))}>Far / strong</Chip>
            </div>
          </section>
          <section className="block">
            <div className="block-title">Suppression camera</div>
            <Slider label="Shutter" value={suppression.shutter} min={1 / 120} max={1 / 4} step={0.001} onChange={(v) => supSet("shutter", v)} />
            <Slider label="Distance" value={suppression.distanceM} min={5} max={80} step={0.5} onChange={(v) => supSet("distanceM", v)} />
            <Slider label="Light lux" value={suppression.lightLux} min={50} max={8000} step={10} onChange={(v) => supSet("lightLux", v)} />
            <Slider label="Iris" value={suppression.iris} min={0.05} max={1} step={0.01} onChange={(v) => supSet("iris", v)} />
            <Slider label="Motion speed" value={suppression.motionMps} min={0.1} max={20} step={0.1} onChange={(v) => supSet("motionMps", v)} />
            <Slider label="Focal mm" value={suppression.focalMm} min={12} max={100} step={1} onChange={(v) => supSet("focalMm", v)} />
            <Slider label="Dilution" value={suppression.dilution} min={0} max={1} step={0.01} onChange={(v) => supSet("dilution", v)} />
          </section>
        </>
      )}

      {topMode === "giant" && giantBranch === "blur" && (
        <>
          <section className="block">
            <div className="block-title">Blur-Map looks</div>
            <div className="chips">
              <Chip onClick={() => setBlur((s) => ({ ...s, shutter: 1 / 5, distanceM: 36, iris: 0.72, lightLux: 1600, motionMps: 4.2, focalMm: 42, flowGain: 0.70, tracePersistence: 0.70, streamSigmaPx: 16, antiSsf: 0.50, burnGuard: 0.70, staticPreserve: 0.72, identityFade: 0.56, lateralSoftness: 0.18, colorFlow: 0.38 }))}>Tight flow</Chip>
              <Chip onClick={() => setBlur({ ...DEFAULT_GIANT_BLUR })}>Balanced map</Chip>
              <Chip onClick={() => setBlur((s) => ({ ...s, shutter: 1 / 2, distanceM: 78, iris: 0.92, lightLux: 3000, motionMps: 6.8, focalMm: 80, flowGain: 0.95, tracePersistence: 0.90, streamSigmaPx: 34, antiSsf: 0.74, burnGuard: 0.84, staticPreserve: 0.50, identityFade: 0.86, lateralSoftness: 0.30, colorFlow: 0.60 }))}>Long trace</Chip>
            </div>
          </section>
          <section className="block">
            <div className="block-title">Blur-Map camera</div>
            <Slider label="Shutter" value={blur.shutter} min={1 / 30} max={1 / 1.5} step={0.002} onChange={(v) => blurSet("shutter", v)} />
            <Slider label="Distance" value={blur.distanceM} min={5} max={100} step={0.5} onChange={(v) => blurSet("distanceM", v)} />
            <Slider label="Light lux" value={blur.lightLux} min={50} max={10000} step={10} onChange={(v) => blurSet("lightLux", v)} />
            <Slider label="Iris" value={blur.iris} min={0.05} max={1} step={0.01} onChange={(v) => blurSet("iris", v)} />
            <Slider label="Motion speed" value={blur.motionMps} min={0.1} max={20} step={0.1} onChange={(v) => blurSet("motionMps", v)} />
            <Slider label="Focal mm" value={blur.focalMm} min={12} max={120} step={1} onChange={(v) => blurSet("focalMm", v)} />
            <Slider label="Stream sigma" value={blur.streamSigmaPx} min={2} max={40} step={0.5} onChange={(v) => blurSet("streamSigmaPx", v)} />
          </section>
          <section className="block">
            <div className="block-title">Blur-Map rendering</div>
            <Slider label="Flow gain" value={blur.flowGain} min={0} max={1} step={0.01} onChange={(v) => blurSet("flowGain", v)} />
            <Slider label="Trace persistence" value={blur.tracePersistence} min={0} max={1} step={0.01} onChange={(v) => blurSet("tracePersistence", v)} />
            <Slider label="Anti-SSF" value={blur.antiSsf} min={0} max={1} step={0.01} onChange={(v) => blurSet("antiSsf", v)} />
            <Slider label="Burn guard" value={blur.burnGuard} min={0.05} max={1} step={0.01} onChange={(v) => blurSet("burnGuard", v)} />
            <Slider label="Static preserve" value={blur.staticPreserve} min={0} max={1} step={0.01} onChange={(v) => blurSet("staticPreserve", v)} />
            <Slider label="Identity fade" value={blur.identityFade} min={0} max={1} step={0.01} onChange={(v) => blurSet("identityFade", v)} />
            <Slider label="Color flow" value={blur.colorFlow} min={0} max={1} step={0.01} onChange={(v) => blurSet("colorFlow", v)} />
          </section>
        </>
      )}
    </aside>
  );
}

export default function BasarLabProV22SimulationConfig({ initialConfig = null, externalConfig = null, onTelemetry = null } = {}) {
  const [topMode, setTopMode] = useState("duo");
  const [giantBranch, setGiantBranch] = useState("suppression");
  const [world, setWorld] = useState(DEFAULT_WORLD);
  const [duo, setDuo] = useState(DEFAULT_DUO);
  const [suppression, setSuppression] = useState(DEFAULT_GIANT_SUPPRESSION);
  const [blur, setBlur] = useState(DEFAULT_GIANT_BLUR);

  const activePreview = topMode === "duo" ? duo.preview : giantBranch === "suppression" ? suppression.preview : blur.preview;

  useEffect(() => {
    if (!initialConfig) return;
    applySimulationConfigToState(initialConfig, { setWorld, setDuo, setSuppression, setBlur, setTopMode, setGiantBranch });
  }, []);

  useEffect(() => {
    if (!externalConfig) return;
    applySimulationConfigToState(externalConfig, { setWorld, setDuo, setSuppression, setBlur, setTopMode, setGiantBranch });
  }, [externalConfig]);

  useEffect(() => {
    if (typeof window === "undefined") return;

    const handler = (event) => {
      const payload = event?.data;
      if (!payload || payload.type !== "ABSTRA_SIMULATION_CONFIG") return;
      const normalized = applySimulationConfigToState(payload.config, { setWorld, setDuo, setSuppression, setBlur, setTopMode, setGiantBranch });
      if (normalized && typeof payload.requestId === "string") {
        window.postMessage({
          type: "ABSTRA_SIMULATION_CONFIG_APPLIED",
          requestId: payload.requestId,
          config: normalized,
        }, "*");
      }
    };

    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  useEffect(() => {
    if (typeof onTelemetry !== "function") return;
    const telemetry = buildTelemetrySnapshot({ world, duo, suppression, blur, topMode, giantBranch, activePreview });
    onTelemetry(telemetry);
  }, [world, duo, suppression, blur, topMode, giantBranch, activePreview, onTelemetry]);

  const currentSimulationConfig = useMemo(
    () => createSimulationConfigSnapshot({ world, duo, suppression, blur, topMode, giantBranch, activePreview }),
    [world, duo, suppression, blur, topMode, giantBranch, activePreview]
  );

  return (
    <main className="root" data-simulation-contract={currentSimulationConfig.schemaVersion}>
      <style>{`
        .root { min-height: 100vh; background: #05070b; color: #eef4ff; font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
        .layout { display: grid; grid-template-columns: minmax(350px, 430px) 1fr; min-height: 100vh; }
        .panel { padding: 18px; overflow-y: auto; border-right: 1px solid rgba(255,255,255,0.08); background: radial-gradient(circle at 20% 0%, rgba(87,144,255,0.13), transparent 32%), radial-gradient(circle at 100% 0%, rgba(255,179,102,0.08), transparent 28%), linear-gradient(180deg, #0b1018, #07090d); }
        .stage { position: relative; min-height: 100vh; }
        h1 { margin: 0 0 8px; font-size: 24px; letter-spacing: -0.04em; }
        .desc { margin: 0 0 16px; color: rgba(238,244,255,0.72); font-size: 12px; line-height: 1.7; }
        .block { margin-bottom: 16px; padding: 12px; border: 1px solid rgba(255,255,255,0.075); border-radius: 20px; background: rgba(255,255,255,0.035); box-shadow: inset 0 1px 0 rgba(255,255,255,0.04), 0 18px 46px rgba(0,0,0,0.18); backdrop-filter: blur(14px); }
        .block-title { margin-bottom: 10px; font-size: 11px; letter-spacing: 0.14em; text-transform: uppercase; color: #b9d8ff; }
        .chips { display: flex; flex-wrap: wrap; gap: 8px; }
        .chip { border: 1px solid rgba(255,255,255,0.11); background: rgba(255,255,255,0.045); color: rgba(238,244,255,0.80); border-radius: 999px; padding: 7px 10px; font-size: 11px; cursor: pointer; transition: transform 160ms ease, border-color 160ms ease, background 160ms ease; }
        .chip:hover { transform: translateY(-1px); }
        .chip.active { border-color: rgba(156,213,255,0.58); background: linear-gradient(180deg, rgba(156,213,255,0.18), rgba(156,213,255,0.10)); color: #dff2ff; box-shadow: 0 0 0 1px rgba(156,213,255,0.08) inset; }
        .control { display: block; margin-bottom: 10px; }
        .control span { display: flex; justify-content: space-between; gap: 12px; font-size: 12px; margin-bottom: 4px; }
        .control b { font-weight: 500; }
        .control em { font-style: normal; color: #9cd5ff; font-variant-numeric: tabular-nums; }
        .control input { width: 100%; }
        .screen-label { color: #eef4ff; border: 1px solid rgba(255,255,255,0.12); background: rgba(6,9,15,0.78); border-radius: 999px; padding: 4px 9px; font-size: 10px; letter-spacing: 0.08em; white-space: nowrap; box-shadow: 0 8px 28px rgba(0,0,0,0.28); }
        .hud { pointer-events: none; position: absolute; top: 16px; left: 16px; right: 16px; display: flex; gap: 10px; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; }
        .hud > div { min-width: 0; border: 1px solid rgba(255,255,255,0.10); background: rgba(6,9,15,0.62); backdrop-filter: blur(14px); border-radius: 16px; padding: 9px 11px; box-shadow: 0 18px 60px rgba(0,0,0,0.28); }
        .hud strong { display: block; font-size: 12px; color: #eef4ff; }
        .hud span { display: block; margin-top: 2px; font-size: 10px; color: rgba(238,244,255,0.62); }
        @media (max-width: 940px) { .layout { grid-template-columns: 1fr; } .stage { min-height: 58vh; height: 58vh; order: 1; } .panel { order: 2; border-right: none; border-top: 1px solid rgba(255,255,255,0.08); } .hud { top: 10px; left: 10px; right: 10px; } }
      `}</style>
      <div className="layout">
        <Controls
          topMode={topMode}
          setTopMode={setTopMode}
          giantBranch={giantBranch}
          setGiantBranch={setGiantBranch}
          world={world}
          setWorld={setWorld}
          duo={duo}
          setDuo={setDuo}
          suppression={suppression}
          setSuppression={setSuppression}
          blur={blur}
          setBlur={setBlur}
        />
        <Stage
          world={world}
          duo={duo}
          suppression={suppression}
          blur={blur}
          topMode={topMode}
          giantBranch={giantBranch}
          activePreview={activePreview}
        />
      </div>
    </main>
  );
}
