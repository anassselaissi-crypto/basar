import { useState } from "react";

/**
 * Abstra Memory intro / presentation layer.
 *
 * Contract:
 * - Presentation and entry only.
 * - No Agent 3 controls.
 * - No simulation controls.
 * - Launches the second interface: Abstra Engine workspace.
 */
export default function AbstraMemoryIntro({ onLaunchWorkspace }) {
  const [hover, setHover] = useState(false);

  return (
    <main style={{
      minHeight: "100vh",
      background:
        "radial-gradient(circle at 20% 10%, rgba(167,139,250,0.18), transparent 32%), radial-gradient(circle at 80% 80%, rgba(56,189,248,0.10), transparent 28%), #06090f",
      color: "#e5e7eb",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 24,
      fontFamily: "Inter, ui-sans-serif, system-ui, sans-serif",
    }}>
      <section style={{
        width: "min(920px, 100%)",
        border: "1px solid rgba(255,255,255,0.08)",
        borderRadius: 28,
        background: "rgba(7,11,22,0.72)",
        backdropFilter: "blur(18px)",
        boxShadow: "0 32px 120px rgba(0,0,0,0.38)",
        padding: "clamp(28px, 7vw, 76px)",
      }}>
        <div style={{
          fontFamily: "Syne, Inter, sans-serif",
          fontWeight: 800,
          fontSize: "clamp(42px, 9vw, 92px)",
          letterSpacing: "-0.08em",
          lineHeight: 0.9,
        }}>
          ABSTRA
        </div>

        <div style={{
          marginTop: 12,
          fontFamily: "'Space Mono', monospace",
          fontSize: 11,
          letterSpacing: "0.32em",
          color: "#a78bfa",
          textTransform: "uppercase",
        }}>
          Memory Core
        </div>

        <p style={{
          marginTop: 34,
          maxWidth: 620,
          fontSize: "clamp(15px, 2vw, 19px)",
          lineHeight: 1.85,
          color: "#94a3b8",
        }}>
          A presentation layer for structured memory, analysis, and controlled orchestration.
          This screen is the entry gate only. Workspace logic, Agent 3 activation, and simulation access belong to Abstra Engine.
        </p>

        <button
          onMouseEnter={() => setHover(true)}
          onMouseLeave={() => setHover(false)}
          onClick={onLaunchWorkspace}
          style={{
            marginTop: 34,
            border: "1px solid rgba(167,139,250,0.35)",
            background: hover ? "rgba(167,139,250,0.22)" : "rgba(167,139,250,0.13)",
            color: "#f8fafc",
            borderRadius: 999,
            padding: "14px 22px",
            fontSize: 13,
            fontFamily: "'Space Mono', monospace",
            letterSpacing: "0.08em",
            cursor: "pointer",
            transition: "all 180ms ease",
            transform: hover ? "translateY(-1px)" : "translateY(0)",
          }}
        >
          ENTER / LAUNCH WORKSPACE
        </button>

        <div style={{
          marginTop: 32,
          borderTop: "1px solid rgba(255,255,255,0.06)",
          paddingTop: 18,
          display: "flex",
          flexWrap: "wrap",
          gap: 10,
          color: "#475569",
          fontSize: 11,
          fontFamily: "'Space Mono', monospace",
        }}>
          <span>presentation only</span>
          <span>·</span>
          <span>no simulation controls</span>
          <span>·</span>
          <span>agent 3 lives in engine workspace</span>
        </div>
      </section>
    </main>
  );
}
