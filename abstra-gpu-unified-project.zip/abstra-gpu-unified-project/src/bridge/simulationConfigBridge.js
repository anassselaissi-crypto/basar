export const SIMULATION_CONFIG_EVENT = "ABSTRA_SIMULATION_CONFIG";
export const SIMULATION_CONFIG_APPLIED_EVENT = "ABSTRA_SIMULATION_CONFIG_APPLIED";

export function sendSimulationConfig(config, targetWindow = window, requestId = crypto.randomUUID?.() || String(Date.now())) {
  targetWindow.postMessage({
    type: SIMULATION_CONFIG_EVENT,
    requestId,
    config,
  }, "*");
  return requestId;
}

export function listenForSimulationConfigApplied(callback) {
  const handler = (event) => {
    const payload = event?.data;
    if (!payload || payload.type !== SIMULATION_CONFIG_APPLIED_EVENT) return;
    callback(payload);
  };
  window.addEventListener("message", handler);
  return () => window.removeEventListener("message", handler);
}
