import React, { useMemo, useState } from "react";
import AbstraMemoryIntro from "./components/AbstraMemoryIntro.jsx";
import AbstraEngine from "./components/AbstraEngine.jsx";
import BasarLabPro from "./components/BasarLabPro.jsx";

const INITIAL_VIEW = "intro";

export default function App() {
  const [view, setView] = useState(INITIAL_VIEW);
  const [latestTelemetry, setLatestTelemetry] = useState(null);
  const [externalConfig, setExternalConfig] = useState(null);

  const nav = useMemo(() => ([
    ["intro", "Memory"],
    ["engine", "Engine"],
    ["basar", "BasarLab"],
  ]), []);

  if (view === "intro") {
    return <AbstraMemoryIntro onLaunchWorkspace={() => setView("engine")} />;
  }

  return (
    <main style={{ minHeight: "100vh", background: "#05070b", color: "#e5e7eb" }}>
      <div style={{
        position: "fixed",
        zIndex: 50,
        top: 12,
        right: 12,
        display: "flex",
        gap: 8,
        padding: 8,
        border: "1px solid rgba(255,255,255,0.08)",
        borderRadius: 999,
        background: "rgba(6,9,15,0.72)",
        backdropFilter: "blur(14px)",
      }}>
        {nav.map(([id, label]) => (
          <button
            key={id}
            onClick={() => setView(id)}
            style={{
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: 999,
              padding: "7px 11px",
              background: view === id ? "rgba(167,139,250,0.18)" : "rgba(255,255,255,0.04)",
              color: view === id ? "#c4b5fd" : "#94a3b8",
              cursor: "pointer",
              fontSize: 11,
              fontFamily: "'Space Mono', monospace",
            }}
          >
            {label}
          </button>
        ))}
      </div>

      {view === "engine" && <AbstraEngine />}
      {view === "basar" && (
        <BasarLabPro
          externalConfig={externalConfig}
          onTelemetry={(telemetry) => setLatestTelemetry(telemetry)}
        />
      )}

      {view === "basar" && latestTelemetry && (
        <div style={{
          position: "fixed",
          left: 16,
          bottom: 16,
          zIndex: 55,
          maxWidth: 360,
          border: "1px solid rgba(56,189,248,0.16)",
          background: "rgba(6,9,15,0.74)",
          backdropFilter: "blur(14px)",
          borderRadius: 16,
          padding: 12,
          color: "#94a3b8",
          fontSize: 11,
          lineHeight: 1.6,
          fontFamily: "'Space Mono', monospace",
        }}>
          <div style={{ color: "#38bdf8", marginBottom: 4 }}>Basar telemetry</div>
          <div>mode: {latestTelemetry.mode}</div>
          <div>blurPx: {Number(latestTelemetry.blurPx || 0).toFixed(2)}</div>
          <div>burnRisk: {Number(latestTelemetry.burnRisk || 0).toFixed(3)}</div>
        </div>
      )}
    </main>
  );
}
