import express from "express";
import cors from "cors";
import "dotenv/config";

const app = express();
app.use(cors());
app.use(express.json({ limit: "8mb" }));

function getProviderKey(provider, req) {
  const ephemeral = req.headers["x-abstra-ephemeral-key"];
  if (typeof ephemeral === "string" && ephemeral.trim()) return ephemeral.trim();

  if (provider === "claude") return process.env.ANTHROPIC_API_KEY;
  if (provider === "openai") return process.env.OPENAI_API_KEY;
  if (provider === "gemini") return process.env.GEMINI_API_KEY;
  return "";
}

app.get("/health", (_, res) => {
  res.json({ ok: true, service: "abstra-llm-proxy" });
});

app.post("/api/llm", async (req, res) => {
  const { provider = process.env.LLM_PROVIDER || "claude", system = "", messages = [] } = req.body || {};
  const key = getProviderKey(provider, req);

  if (!key && provider !== "local") {
    return res.status(400).json({
      error: {
        message: `Missing API key for provider '${provider}'. Set server env or pass an ephemeral prototype token.`,
      },
    });
  }

  try {
    // This proxy intentionally keeps cloud provider calls centralized.
    // Wire provider-specific SDK/API details here in production.
    // The frontend contract expects: { text: string }
    if (provider === "local") {
      return res.status(400).json({ error: { message: "Use the local endpoint directly from the Agent 3 panel." } });
    }

    return res.status(501).json({
      error: {
        message:
          "LLM proxy route is ready but provider-specific implementation is intentionally left server-side. Add Claude/OpenAI/Gemini SDK calls here.",
      },
      debug: { provider, hasSystem: Boolean(system), messages: messages.length },
    });
  } catch (error) {
    res.status(500).json({ error: { message: error.message || String(error) } });
  }
});

const port = Number(process.env.LLM_PROXY_PORT || 8787);
app.listen(port, () => {
  console.log(`Abstra LLM proxy listening on :${port}`);
});
